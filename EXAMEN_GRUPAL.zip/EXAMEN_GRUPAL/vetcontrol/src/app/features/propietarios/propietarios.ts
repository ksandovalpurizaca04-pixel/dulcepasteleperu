
import {
  Component,
  OnInit,
  inject
} from '@angular/core';

import {
  CommonModule
} from '@angular/common';

import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';

import {
  Propietario
} from '../../core/models/propietario.model';

import {
  PropietarioService
} from '../../core/services/propietario';

@Component({
  selector: 'app-propietarios',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  templateUrl: './propietarios.html',
  styleUrl: './propietarios.css'
})
export class Propietarios implements OnInit {

  private propietarioService = inject(PropietarioService);
  private fb = inject(FormBuilder);

  propietarios: Propietario[] = [];
  propietariosFiltrados: Propietario[] = [];

  formulario!: FormGroup;

  busqueda: string = '';
  editando: boolean = false;
  propietarioEditandoId: number | null = null;
  mostrarFormulario: boolean = false;

  mensaje: string = '';
  tipoMensaje: 'success' | 'danger' = 'success';

  ngOnInit(): void {
    this.crearFormulario();
    this.cargarPropietarios();
  }

  // Crear formulario reactivo
  crearFormulario(): void {

    this.formulario = this.fb.group({

      nombres: [
        '',
        [
          Validators.required,
          Validators.minLength(3),
          Validators.maxLength(60)
        ]
      ],

      apellidos: [
        '',
        [
          Validators.required,
          Validators.minLength(3),
          Validators.maxLength(60)
        ]
      ],

      dni: [
        '',
        [
          Validators.required,
          Validators.pattern(/^\d{8}$/)
        ]
      ],

      telefono: [
        '',
        [
          Validators.required,
          Validators.pattern(/^9\d{8}$/)
        ]
      ],

      correo: [
        '',
        [
          Validators.required,
          Validators.email
        ]
      ],

      direccion: [
        '',
        [
          Validators.maxLength(150)
        ]
      ]

    });
  }

  // Obtener propietarios registrados
  cargarPropietarios(): void {

    this.propietarios =
      this.propietarioService.obtenerTodos();

    this.filtrarPropietarios();
  }

  // Buscar propietarios
  filtrarPropietarios(): void {

    const texto = this.busqueda
      .trim()
      .toLowerCase();

    this.propietariosFiltrados =
      this.propietarios.filter(propietario => {

        const nombreCompleto =
          `${propietario.nombres} ${propietario.apellidos}`
            .toLowerCase();

        return (
          nombreCompleto.includes(texto) ||
          propietario.dni.includes(texto) ||
          propietario.correo.toLowerCase().includes(texto)
        );
      });
  }

  // Abrir formulario de registro
  nuevoPropietario(): void {

    this.editando = false;
    this.propietarioEditandoId = null;

    this.formulario.reset();

    this.mostrarFormulario = true;
    this.mensaje = '';
  }

  // Editar propietario existente
  editarPropietario(propietario: Propietario): void {

    this.editando = true;
    this.propietarioEditandoId = propietario.id;

    this.formulario.patchValue({
      nombres: propietario.nombres,
      apellidos: propietario.apellidos,
      dni: propietario.dni,
      telefono: propietario.telefono,
      correo: propietario.correo,
      direccion: propietario.direccion ?? ''
    });

    this.mostrarFormulario = true;
    this.mensaje = '';
  }

  // Guardar registro o modificación
  guardarPropietario(): void {

    if (this.formulario.invalid) {
      this.formulario.markAllAsTouched();

      this.mostrarMensaje(
        'Complete correctamente todos los campos obligatorios.',
        'danger'
      );

      return;
    }

    const datos = {
      nombres: this.formulario.value.nombres.trim(),
      apellidos: this.formulario.value.apellidos.trim(),
      dni: this.formulario.value.dni.trim(),
      telefono: this.formulario.value.telefono.trim(),
      correo: this.formulario.value.correo.trim().toLowerCase(),
      direccion: (this.formulario.value.direccion ?? '').trim()
    };

    // Validar DNI duplicado
    const dniDuplicado = this.propietarios.some(
      propietario =>
        propietario.dni === datos.dni &&
        propietario.id !== this.propietarioEditandoId
    );

    if (dniDuplicado) {
      this.mostrarMensaje(
        'Ya existe un propietario registrado con ese DNI.',
        'danger'
      );
      return;
    }

    // Validar correo duplicado
    const correoDuplicado = this.propietarios.some(
      propietario =>
        propietario.correo.toLowerCase() === datos.correo &&
        propietario.id !== this.propietarioEditandoId
    );

    if (correoDuplicado) {
      this.mostrarMensaje(
        'Ya existe un propietario registrado con ese correo.',
        'danger'
      );
      return;
    }

    try {

      if (this.editando && this.propietarioEditandoId !== null) {

        const actualizado = this.propietarioService.actualizar(
          this.propietarioEditandoId,
          datos
        );

        if (!actualizado) {
          throw new Error('No se encontró el propietario.');
        }

        this.mostrarMensaje(
          'Propietario actualizado correctamente.',
          'success'
        );

      } else {

        this.propietarioService.registrar(datos);

        this.mostrarMensaje(
          'Propietario registrado correctamente.',
          'success'
        );
      }

      this.cargarPropietarios();
      this.cancelarFormulario();

    } catch (error) {

      const mensajeError = error instanceof Error
        ? error.message
        : 'Ocurrió un error al guardar el propietario.';

      this.mostrarMensaje(mensajeError, 'danger');
    }
  }

  // Eliminar propietario
  
  eliminarPropietario(propietario: Propietario): void {

    const confirmar = confirm(
      `¿Está seguro de eliminar a ${propietario.nombres} ${propietario.apellidos}?`
    );

    if (!confirmar) {
      return;
    }

    try {

      const eliminado = this.propietarioService.eliminar(
        propietario.id
      );

      if (eliminado) {

        this.cargarPropietarios();

        this.mostrarMensaje(
          'Propietario eliminado correctamente.',
          'success'
        );

      } else {

        this.mostrarMensaje(
          'No se encontró el propietario que desea eliminar.',
          'danger'
        );
      }

    } catch (error) {

      const mensajeError = error instanceof Error
        ? error.message
        : 'No se pudo eliminar el propietario.';

      this.mostrarMensaje(
        mensajeError,
        'danger'
      );
    }
  }


  // Cerrar formulario
  cancelarFormulario(): void {

    this.mostrarFormulario = false;
    this.editando = false;
    this.propietarioEditandoId = null;

    this.formulario.reset();
  }

  // Mostrar alertas
  mostrarMensaje(
    texto: string,
    tipo: 'success' | 'danger'
  ): void {

    this.mensaje = texto;
    this.tipoMensaje = tipo;
  }

  // Consultar errores de un campo
  campoInvalido(nombreCampo: string): boolean {

    const campo = this.formulario.get(nombreCampo);

    return !!(
      campo &&
      campo.invalid &&
      (campo.touched || campo.dirty)
    );
  }
}
