
import {
  Component,
  OnInit,
  inject
} from '@angular/core';

import {
  DatePipe,
  NgFor,
  NgIf,
  NgClass
} from '@angular/common';

import { RouterLink } from '@angular/router';

import { PropietarioService } from '../../core/services/propietario';
import { MascotaService } from '../../core/services/mascota';
import { CitaService } from '../../core/services/cita';
import { HistorialService } from '../../core/services/historial';

import {
  Cita,
  EstadoCita
} from '../../core/models/cita.model';

@Component({
  selector: 'app-inicio',
  standalone: true,
  imports: [
    DatePipe,
    NgFor,
    NgIf,
    NgClass,
    RouterLink
  ],
  templateUrl: './inicio.html',
  styleUrl: './inicio.css'
})
export class Inicio implements OnInit {

  private propietarioService = inject(PropietarioService);
  private mascotaService = inject(MascotaService);
  private citaService = inject(CitaService);
  private historialService = inject(HistorialService);

  fechaActual: Date = new Date();

  totalPropietarios: number = 0;
  totalMascotas: number = 0;
  citasHoy: number = 0;
  totalAtenciones: number = 0;

  citasPendientes: number = 0;
  citasConfirmadas: number = 0;
  citasCompletadas: number = 0;

  proximasCitas: Cita[] = [];

  ngOnInit(): void {
    this.cargarEstadisticas();
  }

  cargarEstadisticas(): void {

    const propietarios =
      this.propietarioService.obtenerTodos();

    const mascotas =
      this.mascotaService.obtenerTodos();

    const citas =
      this.citaService.obtenerTodos();

    const historiales =
      this.historialService.obtenerTodos();

    this.totalPropietarios = propietarios.length;
    this.totalMascotas = mascotas.length;
    this.totalAtenciones = historiales.length;

    const hoy = this.obtenerFechaLocal(new Date());

    this.citasHoy = citas.filter(
      cita =>
        cita.fecha === hoy &&
        cita.estado !== EstadoCita.CANCELADA
    ).length;

    this.citasPendientes = citas.filter(
      cita => cita.estado === EstadoCita.PENDIENTE
    ).length;

    this.citasConfirmadas = citas.filter(
      cita => cita.estado === EstadoCita.CONFIRMADA
    ).length;

    this.citasCompletadas = citas.filter(
      cita => cita.estado === EstadoCita.COMPLETADA
    ).length;

    const ahora = new Date();

    this.proximasCitas = citas
      .filter(cita => {

        if (
          cita.estado === EstadoCita.CANCELADA ||
          cita.estado === EstadoCita.COMPLETADA
        ) {
          return false;
        }

        const fechaHora = new Date(
          `${cita.fecha}T${cita.hora}:00`
        );

        return fechaHora >= ahora;
      })
      .sort((a, b) =>
        `${a.fecha}T${a.hora}`.localeCompare(
          `${b.fecha}T${b.hora}`
        )
      )
      .slice(0, 5);
  }

  obtenerNombreMascota(mascotaId: number): string {

    const mascota =
      this.mascotaService.obtenerPorId(mascotaId);

    return mascota?.nombre ?? 'Mascota no encontrada';
  }

  obtenerFechaLocal(fecha: Date): string {

    const anio = fecha.getFullYear();

    const mes = String(
      fecha.getMonth() + 1
    ).padStart(2, '0');

    const dia = String(
      fecha.getDate()
    ).padStart(2, '0');

    return `${anio}-${mes}-${dia}`;
  }

  obtenerClaseEstado(estado: EstadoCita): string {

    switch (estado) {

      case EstadoCita.PENDIENTE:
        return 'bg-warning text-dark';

      case EstadoCita.CONFIRMADA:
        return 'bg-primary';

      case EstadoCita.EN_ATENCION:
        return 'bg-info text-dark';

      case EstadoCita.COMPLETADA:
        return 'bg-success';

      case EstadoCita.CANCELADA:
        return 'bg-danger';

      default:
        return 'bg-secondary';
    }
  }
}
