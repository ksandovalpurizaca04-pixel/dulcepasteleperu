
import {
  Component,
  OnInit,
  inject
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

import {
  Cita,
  EstadoCita
} from '../../core/models/cita.model';

import {
  CitaService
} from '../../core/services/cita';

import {
  MascotaService
} from '../../core/services/mascota';

import {
  PropietarioService
} from '../../core/services/propietario';

// ========================================
// MODELO DE LOS DÍAS DEL CALENDARIO
// ========================================

interface DiaCalendario {
  fecha: string;
  numero: number;
  mesActual: boolean;
  esHoy: boolean;
  seleccionado: boolean;
  citas: Cita[];
}

@Component({
  selector: 'app-calendario',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink
  ],
  templateUrl: './calendario.html',
  styleUrl: './calendario.css'
})
export class Calendario implements OnInit {

  // Permite utilizar el enum en el HTML.
  readonly EstadoCita = EstadoCita;

  private citaService = inject(CitaService);

  private mascotaService = inject(MascotaService);

  private propietarioService = inject(
    PropietarioService
  );

  // ========================================
  // DATOS GENERALES
  // ========================================

  citas: Cita[] = [];

  diasCalendario: DiaCalendario[] = [];

  citasDiaSeleccionado: Cita[] = [];

  fechaActual = new Date();

  mesVisualizado = new Date();

  fechaSeleccionada = '';

  tituloMes = '';

  // ========================================
  // CONFIGURACIÓN
  // ========================================

  diasSemana: string[] = [
    'Lun',
    'Mar',
    'Mié',
    'Jue',
    'Vie',
    'Sáb',
    'Dom'
  ];

  nombresMeses: string[] = [
    'Enero',
    'Febrero',
    'Marzo',
    'Abril',
    'Mayo',
    'Junio',
    'Julio',
    'Agosto',
    'Septiembre',
    'Octubre',
    'Noviembre',
    'Diciembre'
  ];

  // ========================================
  // INICIALIZACIÓN
  // ========================================

  ngOnInit(): void {

    const hoy = new Date();

    this.fechaActual = hoy;

    this.mesVisualizado = new Date(
      hoy.getFullYear(),
      hoy.getMonth(),
      1
    );

    this.fechaSeleccionada =
      this.obtenerFechaLocal(hoy);

    this.cargarCitas();
  }

  // ========================================
  // CARGAR CITAS
  // ========================================

  cargarCitas(): void {

    this.citas = this.citaService.obtenerTodos();

    this.generarCalendario();

    this.cargarCitasDiaSeleccionado();
  }

  // ========================================
  // GENERAR CALENDARIO
  // ========================================

  generarCalendario(): void {

    const anio = this.mesVisualizado.getFullYear();

    const mes = this.mesVisualizado.getMonth();

    this.tituloMes =
      `${this.nombresMeses[mes]} ${anio}`;

    const primerDiaMes = new Date(
      anio,
      mes,
      1
    );

    const ultimoDiaMes = new Date(
      anio,
      mes + 1,
      0
    );

    // Semana que comienza en lunes.
    const desplazamiento =
      (primerDiaMes.getDay() + 6) % 7;

    const totalDias = ultimoDiaMes.getDate();

    const totalCeldas = Math.ceil(
      (desplazamiento + totalDias) / 7
    ) * 7;

    const hoy = this.obtenerFechaLocal(
      new Date()
    );

    const dias: DiaCalendario[] = [];

    for (let i = 0; i < totalCeldas; i++) {

      const fecha = new Date(
        anio,
        mes,
        1 - desplazamiento + i
      );

      const fechaTexto =
        this.obtenerFechaLocal(fecha);

      const citasFecha = this.citas.filter(
        cita => cita.fecha === fechaTexto
      );

      dias.push({
        fecha: fechaTexto,
        numero: fecha.getDate(),
        mesActual: fecha.getMonth() === mes,
        esHoy: fechaTexto === hoy,
        seleccionado:
          fechaTexto === this.fechaSeleccionada,
        citas: citasFecha
      });

    }

    this.diasCalendario = dias;
  }

  // ========================================
  // MES ANTERIOR
  // ========================================

  mesAnterior(): void {

    this.mesVisualizado = new Date(
      this.mesVisualizado.getFullYear(),
      this.mesVisualizado.getMonth() - 1,
      1
    );

    this.generarCalendario();
  }

  // ========================================
  // MES SIGUIENTE
  // ========================================

  mesSiguiente(): void {

    this.mesVisualizado = new Date(
      this.mesVisualizado.getFullYear(),
      this.mesVisualizado.getMonth() + 1,
      1
    );

    this.generarCalendario();
  }

  // ========================================
  // REGRESAR A HOY
  // ========================================

  irAHoy(): void {

    const hoy = new Date();

    this.fechaActual = hoy;

    this.mesVisualizado = new Date(
      hoy.getFullYear(),
      hoy.getMonth(),
      1
    );

    this.fechaSeleccionada =
      this.obtenerFechaLocal(hoy);

    this.cargarCitas();
  }

  // ========================================
  // SELECCIONAR DÍA
  // ========================================

  seleccionarDia(dia: DiaCalendario): void {

    this.fechaSeleccionada = dia.fecha;

    const fecha = new Date(
      `${dia.fecha}T12:00:00`
    );

    if (
      fecha.getMonth() !==
        this.mesVisualizado.getMonth() ||
      fecha.getFullYear() !==
        this.mesVisualizado.getFullYear()
    ) {

      this.mesVisualizado = new Date(
        fecha.getFullYear(),
        fecha.getMonth(),
        1
      );
    }

    this.generarCalendario();

    this.cargarCitasDiaSeleccionado();
  }

  // ========================================
  // CITAS DEL DÍA
  // ========================================

  cargarCitasDiaSeleccionado(): void {

    this.citasDiaSeleccionado = this.citas
      .filter(
        cita =>
          cita.fecha === this.fechaSeleccionada
      )
      .sort(
        (a, b) =>
          a.hora.localeCompare(b.hora)
      );
  }

  // ========================================
  // CONTAR CITAS POR ESTADO
  // ========================================

  contarCitasPorEstado(
    estado: EstadoCita
  ): number {

    return this.citasDiaSeleccionado.filter(
      cita => cita.estado === estado
    ).length;
  }

  // ========================================
  // CITAS DEL MES
  // ========================================

  contarCitasMes(): number {

    const anio = this.mesVisualizado.getFullYear();

    const mes = String(
      this.mesVisualizado.getMonth() + 1
    ).padStart(2, '0');

    const prefijo = `${anio}-${mes}-`;

    return this.citas.filter(
      cita => cita.fecha.startsWith(prefijo)
    ).length;
  }

  // ========================================
  // NOMBRE DE MASCOTA
  // ========================================

  obtenerNombreMascota(
    mascotaId: number
  ): string {

    const mascota =
      this.mascotaService.obtenerPorId(mascotaId);

    return mascota
      ? mascota.nombre
      : 'Mascota no encontrada';
  }

  // ========================================
  // NOMBRE DE PROPIETARIO
  // ========================================

  obtenerNombrePropietario(
    mascotaId: number
  ): string {

    const mascota =
      this.mascotaService.obtenerPorId(mascotaId);

    if (!mascota) {
      return 'No disponible';
    }

    const propietario =
      this.propietarioService.obtenerPorId(
        mascota.propietarioId
      );

    return propietario
      ? `${propietario.nombres} ${propietario.apellidos}`
      : 'Propietario no encontrado';
  }

  // ========================================
  // CLASE CSS SEGÚN ESTADO
  // ========================================

  obtenerClaseEstado(
    estado: EstadoCita
  ): string {

    switch (estado) {

      case EstadoCita.PENDIENTE:
        return 'estado-pendiente';

      case EstadoCita.CONFIRMADA:
        return 'estado-confirmada';

      case EstadoCita.EN_ATENCION:
        return 'estado-atencion';

      case EstadoCita.COMPLETADA:
        return 'estado-completada';

      case EstadoCita.CANCELADA:
        return 'estado-cancelada';

      default:
        return '';
    }
  }

  // ========================================
  // FORMATEAR FECHA SELECCIONADA
  // ========================================

  obtenerFechaSeleccionadaFormateada(): string {

    if (!this.fechaSeleccionada) {
      return '';
    }

    const fecha = new Date(
      `${this.fechaSeleccionada}T12:00:00`
    );

    return fecha.toLocaleDateString(
      'es-PE',
      {
        weekday: 'long',
        day: 'numeric',
        month: 'long',
        year: 'numeric'
      }
    );
  }

  // ========================================
  // FORMATO YYYY-MM-DD
  // ========================================

  obtenerFechaLocal(
    fecha: Date
  ): string {

    const anio = fecha.getFullYear();

    const mes = String(
      fecha.getMonth() + 1
    ).padStart(2, '0');

    const dia = String(
      fecha.getDate()
    ).padStart(2, '0');

    return `${anio}-${mes}-${dia}`;
  }

  // ========================================
  // IDENTIFICADORES NGFOR
  // ========================================

  identificarDia(
    index: number,
    dia: DiaCalendario
  ): string {

    return dia.fecha;
  }

  identificarCita(
    index: number,
    cita: Cita
  ): number {

    return cita.id;
  }

}
