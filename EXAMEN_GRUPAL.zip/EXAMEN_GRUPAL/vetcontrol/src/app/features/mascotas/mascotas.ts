
import {
  Component,
  OnInit,
  inject
} from '@angular/core';

import { CommonModule } from '@angular/common';

import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';

import {
  Mascota,
  SexoMascota
} from '../../core/models/mascota.model';

import {
  Propietario
} from '../../core/models/propietario.model';

import {
  MascotaService
} from '../../core/services/mascota';

import {
  PropietarioService
} from '../../core/services/propietario';

@Component({
  selector: 'app-mascotas',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  templateUrl: './mascotas.html',
  styleUrl: './mascotas.css'
})
export class Mascotas implements OnInit {

  private fb = inject(FormBuilder);

  private mascotaService = inject(MascotaService);

  private propietarioService = inject(
    PropietarioService
  );

  mascotas: Mascota[] = [];
  mascotasFiltradas: Mascota[] = [];

  propietarios: Propietario[] = [];

  formulario!: FormGroup;

  busqueda: string = '';

  editando: boolean = false;

  mascotaEditandoId: number | null = null;

  mostrarFormulario: boolean = false;

  mensaje: string = '';

  tipoMensaje: 'success' | 'danger' = 'success';

  fechaMaxima: string = '';

  sexos = Object.values(SexoMascota);

  especies: string[] = [
    'Perro',
    'Gato',
    'Ave',
    'Conejo',
    'Hámster',
    'Tortuga',
    'Otro'
  ];

  ngOnInit(): void {

    this.fechaMaxima = this.obtenerFechaLocal(
      new Date()
    );

    this.crearFormulario();

    this.cargarPropietarios();

    this.cargarMascotas();
  }

  // ========================================
  // CREAR FORMULARIO REACTIVO
  // ========================================

  crearFormulario(): void {

    this.formulario = this.fb.group({

      nombre: [
        '',
        [
          Validators.required,
          Validators.minLength(2),
          Validators.maxLength(60)
        ]
      ],

      especie: [
        '',
        Validators.required
      ],

      raza: [
        '',
        [
          Validators.required,
          Validators.maxLength(60)
        ]
      ],

      sexo: [
        '',
        Validators.required
      ],

      fechaNacimiento: [
        '',
        Validators.required
      ],

      color: [
        '',
        [
          Validators.required,
          Validators.maxLength(50)
        ]
      ],

      peso: [
        '',
        [
          Validators.required,
          Validators.min(0.01),
          Validators.max(500)
        ]
      ],

      propietarioId: [
        '',
        Validators.required
      ],

      observaciones: [
        '',
        Validators.maxLength(500)
      ]

    });
  }

  // ========================================
  // CARGAR PROPIETARIOS
  // ========================================

  cargarPropietarios(): void {

    this.propietarios =
      this.propietarioService.obtenerTodos();

    this.propietarios.sort(
      (a, b) =>
        a.nombres.localeCompare(b.nombres)
    );
  }

  // ========================================
  // CARGAR MASCOTAS
  // ========================================

  cargarMascotas(): void {

    this.mascotas =
      this.mascotaService.obtenerTodos();

    this.filtrarMascotas();
  }

  // ========================================
  // BUSCAR MASCOTAS
  // ========================================

  filtrarMascotas(): void {

    const texto = this.busqueda
      .trim()
      .toLowerCase();

    this.mascotasFiltradas =
      this.mascotas.filter(mascota => {

        const propietario =
          this.obtenerNombrePropietario(
            mascota.propietarioId
          ).toLowerCase();

        return (
          mascota.nombre.toLowerCase().includes(texto) ||
          mascota.especie.toLowerCase().includes(texto) ||
          mascota.raza.toLowerCase().includes(texto) ||
          propietario.includes(texto)
        );
      });
  }

  // ========================================
  // ABRIR FORMULARIO DE REGISTRO
  // ========================================

  nuevaMascota(): void {

    this.cargarPropietarios();

    if (this.propietarios.length === 0) {

      this.mostrarMensaje(
        'Primero debe registrar un propietario antes de registrar una mascota.',
        'danger'
      );

      return;
    }

    this.editando = false;

    this.mascotaEditandoId = null;

    this.formulario.reset();

    this.mostrarFormulario = true;

    this.mensaje = '';
  }

  // ========================================
  // EDITAR MASCOTA
  // ========================================

  editarMascota(mascota: Mascota): void {

    this.cargarPropietarios();

    this.editando = true;

    this.mascotaEditandoId = mascota.id;

    this.formulario.patchValue({

      nombre: mascota.nombre,

      especie: mascota.especie,

      raza: mascota.raza,

      sexo: mascota.sexo,

      fechaNacimiento:
        this.obtenerFechaLocal(
          new Date(mascota.fechaNacimiento)
        ),

      color: mascota.color,

      peso: mascota.peso,

      propietarioId: mascota.propietarioId,

      observaciones: mascota.observaciones ?? ''

    });

    this.mostrarFormulario = true;

    this.mensaje = '';
  }

  // ========================================
  // GUARDAR MASCOTA
  // ========================================

  guardarMascota(): void {

    if (this.formulario.invalid) {

      this.formulario.markAllAsTouched();

      this.mostrarMensaje(
        'Complete correctamente los campos obligatorios.',
        'danger'
      );

      return;
    }

    const valores = this.formulario.value;

    const fechaNacimiento = new Date(
      `${valores.fechaNacimiento}T00:00:00`
    );

    if (
      Number.isNaN(fechaNacimiento.getTime()) ||
      this.obtenerFechaLocal(fechaNacimiento) !==
        valores.fechaNacimiento
    ) {

      this.mostrarMensaje(
        'La fecha de nacimiento no es válida.',
        'danger'
      );

      return;
    }

    const hoy = new Date();

    hoy.setHours(0, 0, 0, 0);

    if (fechaNacimiento > hoy) {

      this.mostrarMensaje(
        'La fecha de nacimiento no puede ser futura.',
        'danger'
      );

      return;
    }

    const datos = {

      nombre: String(valores.nombre).trim(),

      especie: String(valores.especie).trim(),

      raza: String(valores.raza).trim(),

      sexo: valores.sexo as SexoMascota,

      fechaNacimiento: fechaNacimiento,

      color: String(valores.color).trim(),

      peso: Number(valores.peso),

      propietarioId: Number(valores.propietarioId),

      observaciones:
        String(valores.observaciones ?? '').trim()

    };

    if (
      !datos.nombre ||
      !datos.raza ||
      !datos.color
    ) {

      this.mostrarMensaje(
        'Los campos de texto obligatorios no pueden contener solo espacios.',
        'danger'
      );

      return;
    }

    if (
      !Number.isFinite(datos.peso) ||
      datos.peso <= 0 ||
      datos.peso > 500
    ) {

      this.mostrarMensaje(
        'El peso debe ser mayor que 0 y no superar 500 kg.',
        'danger'
      );

      return;
    }

    try {

      if (
        this.editando &&
        this.mascotaEditandoId !== null
      ) {

        const actualizado =
          this.mascotaService.actualizar(
            this.mascotaEditandoId,
            datos
          );

        if (!actualizado) {
          throw new Error(
            'No se encontró la mascota que desea actualizar.'
          );
        }

        this.mostrarMensaje(
          'Mascota actualizada correctamente.',
          'success'
        );

      } else {

        this.mascotaService.registrar(datos);

        this.mostrarMensaje(
          'Mascota registrada correctamente.',
          'success'
        );
      }

      this.cargarMascotas();

      this.cancelarFormulario();

    } catch (error) {

      const mensajeError = error instanceof Error
        ? error.message
        : 'Ocurrió un error al guardar la mascota.';

      this.mostrarMensaje(
        mensajeError,
        'danger'
      );
    }
  }

  // ========================================
  // ELIMINAR MASCOTA
  // ========================================

  eliminarMascota(mascota: Mascota): void {

    const confirmar = confirm(
      `¿Está seguro de eliminar a la mascota ${mascota.nombre}?`
    );

    if (!confirmar) {
      return;
    }

    try {

      const eliminado =
        this.mascotaService.eliminar(
          mascota.id
        );

      if (eliminado) {

        this.cargarMascotas();

        this.mostrarMensaje(
          'Mascota eliminada correctamente.',
          'success'
        );

      } else {

        this.mostrarMensaje(
          'No se encontró la mascota.',
          'danger'
        );
      }

    } catch (error) {

      const mensajeError = error instanceof Error
        ? error.message
        : 'No se pudo eliminar la mascota.';

      this.mostrarMensaje(
        mensajeError,
        'danger'
      );
    }
  }

  // ========================================
  // OBTENER NOMBRE DEL PROPIETARIO
  // ========================================

  obtenerNombrePropietario(
    propietarioId: number
  ): string {

    const propietario =
      this.propietarioService.obtenerPorId(
        propietarioId
      );

    if (!propietario) {
      return 'Propietario no encontrado';
    }

    return `${propietario.nombres} ${propietario.apellidos}`;
  }

  // ========================================
  // CALCULAR EDAD DE LA MASCOTA
  // ========================================

  calcularEdad(
    fechaNacimiento: Date
  ): string {

    const nacimiento = new Date(
      fechaNacimiento
    );

    if (Number.isNaN(nacimiento.getTime())) {
      return 'No disponible';
    }

    const hoy = new Date();

    let anios =
      hoy.getFullYear() - nacimiento.getFullYear();

    let meses =
      hoy.getMonth() - nacimiento.getMonth();

    if (hoy.getDate() < nacimiento.getDate()) {
      meses--;
    }

    if (meses < 0) {
      anios--;
      meses += 12;
    }

    if (anios > 0) {
      return `${anios} año(s)`;
    }

    if (meses > 0) {
      return `${meses} mes(es)`;
    }

    return 'Menos de un mes';
  }

  // ========================================
  // OBTENER FECHA LOCAL
  // ========================================

  obtenerFechaLocal(fecha: Date): string {

    const anio = fecha.getFullYear();

    const mes = String(
      fecha.getMonth() + 1
    ).padStart(2, '0');

    const dia = String(
      fecha.getDate()
    ).padStart(2, '0');

    return `${anio}-${mes}-${dia}`;
  }

  // ========================================
  // CERRAR FORMULARIO
  // ========================================

  cancelarFormulario(): void {

    this.mostrarFormulario = false;

    this.editando = false;

    this.mascotaEditandoId = null;

    this.formulario.reset();
  }

  // ========================================
  // MOSTRAR MENSAJES
  // ========================================

  mostrarMensaje(
    texto: string,
    tipo: 'success' | 'danger'
  ): void {

    this.mensaje = texto;

    this.tipoMensaje = tipo;
  }

  // ========================================
  // VERIFICAR CAMPO INVÁLIDO
  // ========================================

  campoInvalido(nombreCampo: string): boolean {

    const campo =
      this.formulario.get(nombreCampo);

    return !!(
      campo &&
      campo.invalid &&
      (campo.touched || campo.dirty)
    );
  }
}
