
import {
  Component,
  OnInit,
  inject
} from '@angular/core';

import { CommonModule } from '@angular/common';

import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';

import {
  Cita,
  EstadoCita
} from '../../core/models/cita.model';

import {
  Mascota
} from '../../core/models/mascota.model';

import {
  CitaService
} from '../../core/services/cita';

import {
  MascotaService
} from '../../core/services/mascota';

import {
  PropietarioService
} from '../../core/services/propietario';

@Component({
  selector: 'app-citas',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  templateUrl: './citas.html',
  styleUrl: './citas.css'
})
export class Citas implements OnInit {

  private fb = inject(FormBuilder);

  private citaService = inject(CitaService);

  private mascotaService = inject(MascotaService);

  private propietarioService = inject(
    PropietarioService
  );

  // ========================================
  // DATOS
  // ========================================

  citas: Cita[] = [];

  citasFiltradas: Cita[] = [];

  mascotas: Mascota[] = [];

  formulario!: FormGroup;

  // ========================================
  // ESTADO DE LA INTERFAZ
  // ========================================

  mostrarFormulario = false;

  editando = false;

  citaEditandoId: number | null = null;

  busqueda = '';

  filtroEstado = '';

  filtroFecha = '';

  mensaje = '';

  tipoMensaje: 'success' | 'danger' = 'success';

  fechaMinima = '';

  // ========================================
  // OPCIONES
  // ========================================

  estados = Object.values(EstadoCita);

  horarios: string[] = [
    '08:00',
    '09:00',
    '10:00',
    '11:00',
    '12:00',
    '14:00',
    '15:00',
    '16:00',
    '17:00',
    '18:00'
  ];

  motivosFrecuentes: string[] = [
    'Consulta general',
    'Vacunación',
    'Desparasitación',
    'Control médico',
    'Emergencia',
    'Cirugía',
    'Otro'
  ];

  // ========================================
  // INICIALIZACIÓN
  // ========================================

  ngOnInit(): void {

    this.fechaMinima = this.obtenerFechaLocal(
      new Date()
    );

    this.crearFormulario();

    this.cargarMascotas();

    this.cargarCitas();
  }

  // ========================================
  // CREAR FORMULARIO
  // ========================================

  crearFormulario(): void {

    this.formulario = this.fb.group({

      mascotaId: [
        '',
        Validators.required
      ],

      fecha: [
        '',
        Validators.required
      ],

      hora: [
        '',
        Validators.required
      ],

      motivo: [
        '',
        [
          Validators.required,
          Validators.maxLength(200)
        ]
      ],

      veterinario: [
        '',
        [
          Validators.required,
          Validators.minLength(3),
          Validators.maxLength(100)
        ]
      ],

      estado: [
        EstadoCita.PENDIENTE,
        Validators.required
      ],

      observaciones: [
        '',
        Validators.maxLength(500)
      ]

    });
  }

  // ========================================
  // CARGAR MASCOTAS
  // ========================================

  cargarMascotas(): void {

    this.mascotas =
      this.mascotaService.obtenerTodos();

    this.mascotas.sort(
      (a, b) =>
        a.nombre.localeCompare(b.nombre)
    );
  }

  // ========================================
  // CARGAR CITAS
  // ========================================

  cargarCitas(): void {

    this.citas =
      this.citaService.obtenerTodos();

    this.citas.sort((a, b) => {

      const fechaA = `${a.fecha}T${a.hora}`;

      const fechaB = `${b.fecha}T${b.hora}`;

      return fechaA.localeCompare(fechaB);
    });

    this.filtrarCitas();
  }

  // ========================================
  // FILTRAR CITAS
  // ========================================

  filtrarCitas(): void {

    const texto = this.busqueda
      .trim()
      .toLowerCase();

    this.citasFiltradas = this.citas.filter(
      cita => {

        const mascota =
          this.obtenerNombreMascota(
            cita.mascotaId
          ).toLowerCase();

        const propietario =
          this.obtenerNombrePropietario(
            cita.mascotaId
          ).toLowerCase();

        const coincideBusqueda =
          mascota.includes(texto) ||
          propietario.includes(texto) ||
          cita.veterinario.toLowerCase().includes(texto) ||
          cita.motivo.toLowerCase().includes(texto);

        const coincideEstado =
          !this.filtroEstado ||
          cita.estado === this.filtroEstado;

        const coincideFecha =
          !this.filtroFecha ||
          cita.fecha === this.filtroFecha;

        return (
          coincideBusqueda &&
          coincideEstado &&
          coincideFecha
        );
      }
    );
  }

  // ========================================
  // LIMPIAR FILTROS
  // ========================================

  limpiarFiltros(): void {

    this.busqueda = '';

    this.filtroEstado = '';

    this.filtroFecha = '';

    this.filtrarCitas();
  }

  // ========================================
  // ABRIR REGISTRO DE CITA
  // ========================================

  nuevaCita(): void {

    this.cargarMascotas();

    if (this.mascotas.length === 0) {

      this.mostrarMensaje(
        'Primero debe registrar una mascota para programar una cita.',
        'danger'
      );

      return;
    }

    this.editando = false;

    this.citaEditandoId = null;

    this.formulario.reset({
      mascotaId: '',
      fecha: '',
      hora: '',
      motivo: '',
      veterinario: '',
      estado: EstadoCita.PENDIENTE,
      observaciones: ''
    });

    this.mostrarFormulario = true;

    this.mensaje = '';
  }

  // ========================================
  // EDITAR CITA
  // ========================================

  editarCita(cita: Cita): void {

    this.cargarMascotas();

    this.editando = true;

    this.citaEditandoId = cita.id;

    this.formulario.patchValue({

      mascotaId: cita.mascotaId,

      fecha: cita.fecha,

      hora: cita.hora,

      motivo: cita.motivo,

      veterinario: cita.veterinario,

      estado: cita.estado,

      observaciones: cita.observaciones ?? ''

    });

    this.mostrarFormulario = true;

    this.mensaje = '';
  }

  // ========================================
  // GUARDAR CITA
  // ========================================

  guardarCita(): void {

    if (this.formulario.invalid) {

      this.formulario.markAllAsTouched();

      this.mostrarMensaje(
        'Complete correctamente los campos obligatorios.',
        'danger'
      );

      return;
    }

    const valores = this.formulario.value;

    const mascotaId = Number(
      valores.mascotaId
    );

    const fecha = String(
      valores.fecha
    );

    const hora = String(
      valores.hora
    );

    const motivo = String(
      valores.motivo
    ).trim();

    const veterinario = String(
      valores.veterinario
    ).trim();

    const estado = valores.estado as EstadoCita;

    const observaciones = String(
      valores.observaciones ?? ''
    ).trim();

    // ======================================
    // VALIDAR MASCOTA
    // ======================================

    if (!this.mascotaService.obtenerPorId(mascotaId)) {

      this.mostrarMensaje(
        'Debe seleccionar una mascota registrada.',
        'danger'
      );

      return;
    }

    // ======================================
    // VALIDAR FECHA
    // ======================================

    const fechaCita = new Date(
      `${fecha}T00:00:00`
    );

    if (
      Number.isNaN(fechaCita.getTime()) ||
      this.obtenerFechaLocal(fechaCita) !== fecha
    ) {

      this.mostrarMensaje(
        'Ingrese una fecha válida.',
        'danger'
      );

      return;
    }

    if (fecha < this.fechaMinima) {

      this.mostrarMensaje(
        'No se pueden programar citas en fechas pasadas.',
        'danger'
      );

      return;
    }

    // ======================================
    // VALIDAR HORARIO
    // ======================================

    if (!this.horarios.includes(hora)) {

      this.mostrarMensaje(
        'Seleccione un horario permitido.',
        'danger'
      );

      return;
    }

    // ======================================
    // VALIDAR MOTIVO Y VETERINARIO
    // ======================================

    if (!motivo || motivo.length > 200) {

      this.mostrarMensaje(
        'Ingrese un motivo válido para la cita.',
        'danger'
      );

      return;
    }

    if (
      veterinario.length < 3 ||
      veterinario.length > 100
    ) {

      this.mostrarMensaje(
        'Ingrese correctamente el nombre del veterinario.',
        'danger'
      );

      return;
    }

    // ======================================
    // VALIDAR ESTADO
    // ======================================

    if (!this.estados.includes(estado)) {

      this.mostrarMensaje(
        'Seleccione un estado válido.',
        'danger'
      );

      return;
    }

    // ======================================
    // VALIDAR CONFLICTO DE HORARIO
    // ======================================

    const existeConflicto = this.citas.some(
      cita =>

        cita.id !== this.citaEditandoId &&

        cita.fecha === fecha &&

        cita.hora === hora &&

        cita.veterinario.trim().toLowerCase() ===
          veterinario.toLowerCase() &&

        cita.estado !== EstadoCita.CANCELADA &&

        estado !== EstadoCita.CANCELADA
    );

    if (existeConflicto) {

      this.mostrarMensaje(
        'El veterinario ya tiene una cita registrada en esa fecha y hora.',
        'danger'
      );

      return;
    }

    // ======================================
    // PREPARAR DATOS
    // ======================================

    const datos = {

      mascotaId,

      fecha,

      hora,

      motivo,

      veterinario,

      estado,

      observaciones

    };

    // ======================================
    // REGISTRAR O ACTUALIZAR
    // ======================================

    try {

      if (
        this.editando &&
        this.citaEditandoId !== null
      ) {

        const actualizado =
          this.citaService.actualizar(
            this.citaEditandoId,
            datos
          );

        if (!actualizado) {

          throw new Error(
            'No se encontró la cita que desea actualizar.'
          );
        }

        this.mostrarMensaje(
          'Cita actualizada correctamente.',
          'success'
        );

      } else {

        this.citaService.registrar(datos);

        this.mostrarMensaje(
          'Cita registrada correctamente.',
          'success'
        );
      }

      this.cargarCitas();

      this.cancelarFormulario();

    } catch (error) {

      const mensajeError = error instanceof Error
        ? error.message
        : 'Ocurrió un error al guardar la cita.';

      this.mostrarMensaje(
        mensajeError,
        'danger'
      );
    }
  }

  // ========================================
  // CAMBIAR ESTADO DE CITA
  // ========================================

  cambiarEstado(
    cita: Cita,
    nuevoEstado: EstadoCita
  ): void {

    if (cita.estado === nuevoEstado) {
      return;
    }

    const confirmar = confirm(
      `¿Desea cambiar el estado de la cita a "${nuevoEstado}"?`
    );

    if (!confirmar) {
      return;
    }

    try {

      const actualizado =
        this.citaService.cambiarEstado(
          cita.id,
          nuevoEstado
        );

      if (actualizado) {

        this.cargarCitas();

        this.mostrarMensaje(
          'Estado de la cita actualizado correctamente.',
          'success'
        );

      } else {

        this.mostrarMensaje(
          'No se pudo actualizar el estado de la cita.',
          'danger'
        );
      }

    } catch (error) {

      this.mostrarMensaje(
        error instanceof Error
          ? error.message
          : 'Error al cambiar el estado de la cita.',
        'danger'
      );
    }
  }

  // ========================================
  // CANCELAR CITA
  // ========================================

  cancelarCita(cita: Cita): void {

    if (cita.estado === EstadoCita.CANCELADA) {

      this.mostrarMensaje(
        'Esta cita ya se encuentra cancelada.',
        'danger'
      );

      return;
    }

    const confirmar = confirm(
      `¿Está seguro de cancelar la cita de ${this.obtenerNombreMascota(cita.mascotaId)}?`
    );

    if (!confirmar) {
      return;
    }

    try {

      const cancelada =
        this.citaService.cancelar(cita.id);

      if (cancelada) {

        this.cargarCitas();

        this.mostrarMensaje(
          'Cita cancelada correctamente.',
          'success'
        );

      } else {

        this.mostrarMensaje(
          'No se encontró la cita que desea cancelar.',
          'danger'
        );
      }

    } catch (error) {

      this.mostrarMensaje(
        error instanceof Error
          ? error.message
          : 'No se pudo cancelar la cita.',
        'danger'
      );
    }
  }

  // ========================================
  // ELIMINAR CITA
  // ========================================

  eliminarCita(cita: Cita): void {

    const confirmar = confirm(
      '¿Está seguro de eliminar permanentemente esta cita?'
    );

    if (!confirmar) {
      return;
    }

    try {

      const eliminado =
        this.citaService.eliminar(
          cita.id
        );

      if (eliminado) {

        this.cargarCitas();

        this.mostrarMensaje(
          'Cita eliminada correctamente.',
          'success'
        );

      } else {

        this.mostrarMensaje(
          'No se encontró la cita.',
          'danger'
        );
      }

    } catch (error) {

      this.mostrarMensaje(
        error instanceof Error
          ? error.message
          : 'No se pudo eliminar la cita.',
        'danger'
      );
    }
  }

  // ========================================
  // OBTENER NOMBRE DE MASCOTA
  // ========================================

  obtenerNombreMascota(
    mascotaId: number
  ): string {

    const mascota =
      this.mascotaService.obtenerPorId(
        mascotaId
      );

    return mascota
      ? mascota.nombre
      : 'Mascota no encontrada';
  }

  // ========================================
  // OBTENER NOMBRE DE PROPIETARIO
  // ========================================

  obtenerNombrePropietario(
    mascotaId: number
  ): string {

    const mascota =
      this.mascotaService.obtenerPorId(
        mascotaId
      );

    if (!mascota) {
      return 'No disponible';
    }

    const propietario =
      this.propietarioService.obtenerPorId(
        mascota.propietarioId
      );

    return propietario
      ? `${propietario.nombres} ${propietario.apellidos}`
      : 'Propietario no encontrado';
  }

  // ========================================
  // OBTENER CLASE DE ESTADO
  // ========================================

  obtenerClaseEstado(
    estado: EstadoCita
  ): string {

    switch (estado) {

      case EstadoCita.PENDIENTE:
        return 'estado-pendiente';

      case EstadoCita.CONFIRMADA:
        return 'estado-confirmada';

      case EstadoCita.EN_ATENCION:
        return 'estado-atencion';

      case EstadoCita.COMPLETADA:
        return 'estado-completada';

      case EstadoCita.CANCELADA:
        return 'estado-cancelada';

      default:
        return '';
    }
  }

  // ========================================
  // OBTENER FECHA LOCAL
  // ========================================

  obtenerFechaLocal(fecha: Date): string {

    const anio = fecha.getFullYear();

    const mes = String(
      fecha.getMonth() + 1
    ).padStart(2, '0');

    const dia = String(
      fecha.getDate()
    ).padStart(2, '0');

    return `${anio}-${mes}-${dia}`;
  }

  // ========================================
  // CERRAR FORMULARIO
  // ========================================

  cancelarFormulario(): void {

    this.mostrarFormulario = false;

    this.editando = false;

    this.citaEditandoId = null;

    this.formulario.reset();
  }

  // ========================================
  // MOSTRAR MENSAJES
  // ========================================

  mostrarMensaje(
    texto: string,
    tipo: 'success' | 'danger'
  ): void {

    this.mensaje = texto;

    this.tipoMensaje = tipo;
  }

  // ========================================
  // VALIDAR CAMPO DEL FORMULARIO
  // ========================================

  campoInvalido(nombreCampo: string): boolean {

    const campo =
      this.formulario.get(nombreCampo);

    return !!(
      campo &&
      campo.invalid &&
      (campo.touched || campo.dirty)
    );
  }

  // ========================================
  // ESTADÍSTICAS DE CITAS
  // ========================================

  contarPorEstado(
    estado: EstadoCita
  ): number {

    return this.citas.filter(
      cita => cita.estado === estado
    ).length;
  }

  contarCitasHoy(): number {

    const hoy = this.obtenerFechaLocal(
      new Date()
    );

    return this.citas.filter(
      cita =>
        cita.fecha === hoy &&
        cita.estado !== EstadoCita.CANCELADA
    ).length;
  }

  contarCitasPendientes(): number {

    return this.contarPorEstado(
      EstadoCita.PENDIENTE
    );
  }

  contarCitasConfirmadas(): number {

    return this.contarPorEstado(
      EstadoCita.CONFIRMADA
    );
  }

  contarCitasCompletadas(): number {

    return this.contarPorEstado(
      EstadoCita.COMPLETADA
    );
  }

}
