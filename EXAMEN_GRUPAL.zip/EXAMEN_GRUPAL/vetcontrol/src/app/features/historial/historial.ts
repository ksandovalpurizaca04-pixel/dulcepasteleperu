
import {
  Component,
  OnInit,
  inject
} from '@angular/core';

import { CommonModule } from '@angular/common';

import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';

import {
  HistorialMedico,
  TipoAtencion
} from '../../core/models/historial.model';

import {
  EstadoCita,
  Cita
} from '../../core/models/cita.model';

import {
  Mascota
} from '../../core/models/mascota.model';

import {
  HistorialService
} from '../../core/services/historial';

import {
  MascotaService
} from '../../core/services/mascota';

import {
  PropietarioService
} from '../../core/services/propietario';

import {
  CitaService
} from '../../core/services/cita';

@Component({
  selector: 'app-historial',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  templateUrl: './historial.html',
  styleUrl: './historial.css'
})
export class Historial implements OnInit {

  readonly TipoAtencion = TipoAtencion;

  private fb = inject(FormBuilder);

  private historialService = inject(HistorialService);

  private mascotaService = inject(MascotaService);

  private propietarioService = inject(
    PropietarioService
  );

  private citaService = inject(CitaService);

  // ========================================
  // DATOS DEL SISTEMA
  // ========================================

  historiales: HistorialMedico[] = [];

  historialesFiltrados: HistorialMedico[] = [];

  mascotas: Mascota[] = [];

  citasCompletadas: Cita[] = [];

  formulario!: FormGroup;

  // ========================================
  // INTERFAZ
  // ========================================

  mostrarFormulario = false;

  editando = false;

  historialEditandoId: number | null = null;

  busqueda = '';

  filtroMascota = '';

  filtroTipo = '';

  filtroFecha = '';

  mensaje = '';

  tipoMensaje: 'success' | 'danger' = 'success';

  fechaMaxima = '';

  // ========================================
  // OPCIONES DE ATENCIÓN
  // ========================================

  tiposAtencion = Object.values(TipoAtencion);

  // ========================================
  // INICIALIZACIÓN
  // ========================================

  ngOnInit(): void {

    this.fechaMaxima = this.obtenerFechaLocal(
      new Date()
    );

    this.crearFormulario();

    this.cargarMascotas();

    this.cargarHistoriales();
  }

  // ========================================
  // CREAR FORMULARIO REACTIVO
  // ========================================

  crearFormulario(): void {

    this.formulario = this.fb.group({

      mascotaId: [
        '',
        Validators.required
      ],

      citaId: [
        ''
      ],

      fechaAtencion: [
        '',
        Validators.required
      ],

      tipoAtencion: [
        '',
        Validators.required
      ],

      motivo: [
        '',
        [
          Validators.required,
          Validators.maxLength(200)
        ]
      ],

      diagnostico: [
        '',
        [
          Validators.required,
          Validators.maxLength(1000)
        ]
      ],

      tratamiento: [
        '',
        [
          Validators.required,
          Validators.maxLength(1000)
        ]
      ],

      medicamentos: [
        '',
        Validators.maxLength(500)
      ],

      observaciones: [
        '',
        Validators.maxLength(500)
      ],

      veterinario: [
        '',
        [
          Validators.required,
          Validators.minLength(3),
          Validators.maxLength(100)
        ]
      ],

      proximaVisita: [
        ''
      ]

    });

    // Actualizar las citas al cambiar de mascota.
    this.formulario.get('mascotaId')?.valueChanges
      .subscribe(valor => {

        this.cargarCitasCompletadas(Number(valor));

        const citaSeleccionada =
          Number(this.formulario.get('citaId')?.value);

        if (
          citaSeleccionada &&
          !this.citasCompletadas.some(
            cita => cita.id === citaSeleccionada
          )
        ) {

          this.formulario.patchValue(
            { citaId: '' },
            { emitEvent: false }
          );
        }
      });
  }

  // ========================================
  // CARGAR MASCOTAS
  // ========================================

  cargarMascotas(): void {

    this.mascotas =
      this.mascotaService.obtenerTodos();

    this.mascotas.sort(
      (a, b) =>
        a.nombre.localeCompare(b.nombre)
    );
  }

  // ========================================
  // CARGAR HISTORIALES
  // ========================================

  cargarHistoriales(): void {

    this.historiales =
      this.historialService.obtenerTodos();

    this.historiales.sort((a, b) =>
      b.fechaAtencion.localeCompare(a.fechaAtencion) ||
      b.id - a.id
    );

    this.filtrarHistoriales();
  }

  // ========================================
  // FILTRAR HISTORIALES
  // ========================================

  filtrarHistoriales(): void {

    const texto = this.busqueda
      .trim()
      .toLowerCase();

    this.historialesFiltrados =
      this.historiales.filter(historial => {

        const mascota =
          this.obtenerNombreMascota(
            historial.mascotaId
          ).toLowerCase();

        const propietario =
          this.obtenerNombrePropietario(
            historial.mascotaId
          ).toLowerCase();

        const coincideBusqueda =
          mascota.includes(texto) ||
          propietario.includes(texto) ||
          historial.diagnostico.toLowerCase().includes(texto) ||
          historial.veterinario.toLowerCase().includes(texto) ||
          historial.motivo.toLowerCase().includes(texto);

        const coincideMascota =
          !this.filtroMascota ||
          historial.mascotaId === Number(this.filtroMascota);

        const coincideTipo =
          !this.filtroTipo ||
          historial.tipoAtencion === this.filtroTipo;

        const coincideFecha =
          !this.filtroFecha ||
          historial.fechaAtencion === this.filtroFecha;

        return (
          coincideBusqueda &&
          coincideMascota &&
          coincideTipo &&
          coincideFecha
        );
      });
  }

  // ========================================
  // LIMPIAR FILTROS
  // ========================================

  limpiarFiltros(): void {

    this.busqueda = '';

    this.filtroMascota = '';

    this.filtroTipo = '';

    this.filtroFecha = '';

    this.filtrarHistoriales();
  }

  // ========================================
  // ABRIR NUEVO HISTORIAL
  // ========================================

  nuevoHistorial(): void {

    this.cargarMascotas();

    if (this.mascotas.length === 0) {

      this.mostrarMensaje(
        'Primero debe registrar una mascota para crear su historial médico.',
        'danger'
      );

      return;
    }

    this.editando = false;

    this.historialEditandoId = null;

    this.formulario.reset({

      mascotaId: '',

      citaId: '',

      fechaAtencion: this.obtenerFechaLocal(new Date()),

      tipoAtencion: '',

      motivo: '',

      diagnostico: '',

      tratamiento: '',

      medicamentos: '',

      observaciones: '',

      veterinario: '',

      proximaVisita: ''

    });

    this.citasCompletadas = [];

    this.mostrarFormulario = true;

    this.mensaje = '';
  }

  // ========================================
  // EDITAR HISTORIAL
  // ========================================

  editarHistorial(
    historial: HistorialMedico
  ): void {

    this.cargarMascotas();

    this.editando = true;

    this.historialEditandoId = historial.id;

    this.formulario.patchValue({

      mascotaId: historial.mascotaId,

      citaId: historial.citaId ?? '',

      fechaAtencion: historial.fechaAtencion,

      tipoAtencion: historial.tipoAtencion,

      motivo: historial.motivo,

      diagnostico: historial.diagnostico,

      tratamiento: historial.tratamiento,

      medicamentos: historial.medicamentos ?? '',

      observaciones: historial.observaciones ?? '',

      veterinario: historial.veterinario,

      proximaVisita: historial.proximaVisita ?? ''

    });

    this.cargarCitasCompletadas(
      historial.mascotaId
    );

    this.mostrarFormulario = true;

    this.mensaje = '';
  }

  // ========================================
  // CARGAR CITAS COMPLETADAS
  // ========================================

  cargarCitasCompletadas(
    mascotaId: number
  ): void {

    if (
      !Number.isInteger(mascotaId) ||
      mascotaId <= 0
    ) {
      this.citasCompletadas = [];
      return;
    }

    this.citasCompletadas =
      this.citaService
        .obtenerPorMascota(mascotaId)
        .filter(
          cita =>
            cita.estado === EstadoCita.COMPLETADA
        )
        .sort(
          (a, b) =>
            b.fecha.localeCompare(a.fecha)
        );
  }

  // ========================================
  // GUARDAR HISTORIAL MÉDICO
  // ========================================

  guardarHistorial(): void {

    if (this.formulario.invalid) {

      this.formulario.markAllAsTouched();

      this.mostrarMensaje(
        'Complete correctamente todos los campos obligatorios.',
        'danger'
      );

      return;
    }

    const valores = this.formulario.value;

    const mascotaId = Number(
      valores.mascotaId
    );

    const citaId = valores.citaId
      ? Number(valores.citaId)
      : undefined;

    const fechaAtencion =
      String(valores.fechaAtencion);

    const proximaVisita =
      String(valores.proximaVisita ?? '').trim();

    // ======================================
    // VALIDAR MASCOTA
    // ======================================

    if (!this.mascotaService.obtenerPorId(mascotaId)) {

      this.mostrarMensaje(
        'Seleccione una mascota registrada.',
        'danger'
      );

      return;
    }

    // ======================================
    // VALIDAR FECHA DE ATENCIÓN
    // ======================================

    const fecha = new Date(
      `${fechaAtencion}T00:00:00`
    );

    if (
      Number.isNaN(fecha.getTime()) ||
      this.obtenerFechaLocal(fecha) !== fechaAtencion
    ) {

      this.mostrarMensaje(
        'Ingrese una fecha de atención válida.',
        'danger'
      );

      return;
    }

    if (
      fechaAtencion >
      this.obtenerFechaLocal(new Date())
    ) {

      this.mostrarMensaje(
        'La fecha de atención no puede ser futura.',
        'danger'
      );

      return;
    }

    // ======================================
    // VALIDAR PRÓXIMA VISITA
    // ======================================

    if (proximaVisita) {

      const fechaProxima = new Date(
        `${proximaVisita}T00:00:00`
      );

      if (
        Number.isNaN(fechaProxima.getTime()) ||
        this.obtenerFechaLocal(fechaProxima) !== proximaVisita
      ) {

        this.mostrarMensaje(
          'Ingrese una fecha válida para la próxima visita.',
          'danger'
        );

        return;
      }

      if (proximaVisita <= fechaAtencion) {

        this.mostrarMensaje(
          'La próxima visita debe ser posterior a la fecha de atención.',
          'danger'
        );

        return;
      }
    }

    // ======================================
    // VALIDAR CITA VINCULADA
    // ======================================

    if (citaId !== undefined) {

      const cita = this.citaService.obtenerPorId(
        citaId
      );

      if (
        !cita ||
        cita.mascotaId !== mascotaId ||
        cita.estado !== EstadoCita.COMPLETADA
      ) {

        this.mostrarMensaje(
          'La cita vinculada debe pertenecer a la mascota y estar completada.',
          'danger'
        );

        return;
      }
    }

    // ======================================
    // PREPARAR DATOS
    // ======================================

    const datos = {

      mascotaId,

      citaId,

      fechaAtencion,

      tipoAtencion:
        valores.tipoAtencion as TipoAtencion,

      motivo:
        String(valores.motivo).trim(),

      diagnostico:
        String(valores.diagnostico).trim(),

      tratamiento:
        String(valores.tratamiento).trim(),

      medicamentos:
        String(valores.medicamentos ?? '').trim(),

      observaciones:
        String(valores.observaciones ?? '').trim(),

      veterinario:
        String(valores.veterinario).trim(),

      proximaVisita:
        proximaVisita || undefined

    };

    if (
      !datos.motivo ||
      !datos.diagnostico ||
      !datos.tratamiento ||
      !datos.veterinario
    ) {

      this.mostrarMensaje(
        'Los campos obligatorios no pueden contener solamente espacios.',
        'danger'
      );

      return;
    }

    // ======================================
    // REGISTRAR O ACTUALIZAR
    // ======================================

    try {

      if (
        this.editando &&
        this.historialEditandoId !== null
      ) {

        const actualizado =
          this.historialService.actualizar(
            this.historialEditandoId,
            datos
          );

        if (!actualizado) {

          throw new Error(
            'No se encontró el historial que desea actualizar.'
          );
        }

        this.mostrarMensaje(
          'Historial médico actualizado correctamente.',
          'success'
        );

      } else {

        this.historialService.registrar(datos);

        this.mostrarMensaje(
          'Atención médica registrada correctamente.',
          'success'
        );
      }

      this.cargarHistoriales();

      this.cancelarFormulario();

    } catch (error) {

      this.mostrarMensaje(
        error instanceof Error
          ? error.message
          : 'No se pudo guardar el historial médico.',
        'danger'
      );
    }
  }

  // ========================================
  // ELIMINAR HISTORIAL
  // ========================================

  eliminarHistorial(
    historial: HistorialMedico
  ): void {

    const confirmar = confirm(
      '¿Está seguro de eliminar permanentemente este registro médico?'
    );

    if (!confirmar) {
      return;
    }

    try {

      const eliminado =
        this.historialService.eliminar(
          historial.id
        );

      if (eliminado) {

        this.cargarHistoriales();

        this.mostrarMensaje(
          'Registro médico eliminado correctamente.',
          'success'
        );

      } else {

        this.mostrarMensaje(
          'No se encontró el historial médico.',
          'danger'
        );
      }

    } catch (error) {

      this.mostrarMensaje(
        error instanceof Error
          ? error.message
          : 'No se pudo eliminar el historial médico.',
        'danger'
      );
    }
  }

  // ========================================
  // OBTENER NOMBRE DE MASCOTA
  // ========================================

  obtenerNombreMascota(
    mascotaId: number
  ): string {

    const mascota =
      this.mascotaService.obtenerPorId(
        mascotaId
      );

    return mascota
      ? mascota.nombre
      : 'Mascota no encontrada';
  }

  // ========================================
  // OBTENER NOMBRE DE PROPIETARIO
  // ========================================

  obtenerNombrePropietario(
    mascotaId: number
  ): string {

    const mascota =
      this.mascotaService.obtenerPorId(
        mascotaId
      );

    if (!mascota) {
      return 'No disponible';
    }

    const propietario =
      this.propietarioService.obtenerPorId(
        mascota.propietarioId
      );

    return propietario
      ? `${propietario.nombres} ${propietario.apellidos}`
      : 'Propietario no encontrado';
  }

  // ========================================
  // OBTENER DESCRIPCIÓN DE CITA
  // ========================================

  obtenerDescripcionCita(
    citaId?: number
  ): string {

    if (!citaId) {
      return 'Sin cita vinculada';
    }

    const cita = this.citaService.obtenerPorId(
      citaId
    );

    return cita
      ? `${cita.fecha} - ${cita.hora}`
      : 'Cita no encontrada';
  }

  // ========================================
  // FORMATEAR FECHA LOCAL
  // ========================================

  obtenerFechaLocal(
    fecha: Date
  ): string {

    const anio = fecha.getFullYear();

    const mes = String(
      fecha.getMonth() + 1
    ).padStart(2, '0');

    const dia = String(
      fecha.getDate()
    ).padStart(2, '0');

    return `${anio}-${mes}-${dia}`;
  }

  // ========================================
  // CERRAR FORMULARIO
  // ========================================

  cancelarFormulario(): void {

    this.mostrarFormulario = false;

    this.editando = false;

    this.historialEditandoId = null;

    this.citasCompletadas = [];

    this.formulario.reset();
  }

  // ========================================
  // MOSTRAR MENSAJES
  // ========================================

  mostrarMensaje(
    texto: string,
    tipo: 'success' | 'danger'
  ): void {

    this.mensaje = texto;

    this.tipoMensaje = tipo;
  }

  // ========================================
  // VALIDAR CAMPO
  // ========================================

  campoInvalido(
    nombreCampo: string
  ): boolean {

    const campo = this.formulario.get(
      nombreCampo
    );

    return !!(
      campo &&
      campo.invalid &&
      (campo.touched || campo.dirty)
    );
  }

  // ========================================
  // ESTADÍSTICAS
  // ========================================

  contarAtenciones(): number {

    return this.historiales.length;
  }

  contarMascotasAtendidas(): number {

    const mascotasUnicas = new Set(
      this.historiales.map(
        historial => historial.mascotaId
      )
    );

    return mascotasUnicas.size;
  }

  contarAtencionesPorTipo(
    tipo: TipoAtencion
  ): number {

    return this.historiales.filter(
      historial =>
        historial.tipoAtencion === tipo
    ).length;
  }

  contarAtencionesMesActual(): number {

    const hoy = new Date();

    const anio = hoy.getFullYear();

    const mes = String(
      hoy.getMonth() + 1
    ).padStart(2, '0');

    const prefijo = `${anio}-${mes}-`;

    return this.historiales.filter(
      historial =>
        historial.fechaAtencion.startsWith(prefijo)
    ).length;
  }

  // ========================================
  // IDENTIFICAR REGISTROS
  // ========================================

  identificarHistorial(
    index: number,
    historial: HistorialMedico
  ): number {

    return historial.id;
  }

}
