
import { Component } from '@angular/core';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [],
  templateUrl: './footer.html',
  styleUrl: './footer.css'
})
export class Footer {

  nombreSistema: string = 'VetControl';

  version: string = '1.0.0';

  anioActual: number = new Date().getFullYear();

  institucion: string = 'ZEGEL';

  curso: string = 'Desarrollo de Interfaces 3';

}
