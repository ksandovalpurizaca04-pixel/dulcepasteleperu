
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { NgFor } from '@angular/common';
import { RouterLink, RouterLinkActive } from '@angular/router';

interface OpcionMenu {
  titulo: string;
  ruta: string;
  icono: string;
}

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [NgFor, RouterLink, RouterLinkActive],
  templateUrl: './sidebar.html',
  styleUrl: './sidebar.css'
})
export class Sidebar {

  @Input() abierto: boolean = false;

  @Output() cerrarMenu = new EventEmitter<void>();

  opciones: OpcionMenu[] = [
    {
      titulo: 'Inicio',
      ruta: '/inicio',
      icono: '🏠'
    },
    {
      titulo: 'Propietarios',
      ruta: '/propietarios',
      icono: '👥'
    },
    {
      titulo: 'Mascotas',
      ruta: '/mascotas',
      icono: '🐾'
    },
    {
      titulo: 'Citas',
      ruta: '/citas',
      icono: '📋'
    },
    {
      titulo: 'Calendario',
      ruta: '/calendario',
      icono: '📅'
    },
    {
      titulo: 'Historial Médico',
      ruta: '/historial',
      icono: '🩺'
    }
  ];

  seleccionarOpcion(): void {
    this.cerrarMenu.emit();
  }
}
