
import { Component } from '@angular/core';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [DatePipe],
  templateUrl: './navbar.html',
  styleUrl: './navbar.css'
})
export class Navbar {
  nombreSistema: string = 'VetControl';
  descripcion: string = 'Sistema de Gestión Veterinaria';
  fechaActual: Date = new Date();
}
