
import { Routes } from '@angular/router';

export const routes: Routes = [

  // Redirigir la ruta principal a Inicio
  {
    path: '',
    redirectTo: 'inicio',
    pathMatch: 'full'
  },

  // Panel principal
  {
    path: 'inicio',
    loadComponent: () =>
      import('./features/inicio/inicio')
        .then(m => m.Inicio),
    title: 'Inicio | VetControl'
  },

  // Gestión de propietarios
  {
    path: 'propietarios',
    loadComponent: () =>
      import('./features/propietarios/propietarios')
        .then(m => m.Propietarios),
    title: 'Propietarios | VetControl'
  },

  // Gestión de mascotas
  {
    path: 'mascotas',
    loadComponent: () =>
      import('./features/mascotas/mascotas')
        .then(m => m.Mascotas),
    title: 'Mascotas | VetControl'
  },

  // Gestión de citas veterinarias
  {
    path: 'citas',
    loadComponent: () =>
      import('./features/citas/citas')
        .then(m => m.Citas),
    title: 'Citas | VetControl'
  },

  // Calendario de citas
  {
    path: 'calendario',
    loadComponent: () =>
      import('./features/calendario/calendario')
        .then(m => m.Calendario),
    title: 'Calendario | VetControl'
  },

  // Historial médico
  {
    path: 'historial',
    loadComponent: () =>
      import('./features/historial/historial')
        .then(m => m.Historial),
    title: 'Historial Médico | VetControl'
  },

  // Rutas inexistentes
  {
    path: '**',
    redirectTo: 'inicio'
  }

];
