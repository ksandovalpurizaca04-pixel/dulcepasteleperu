
import { Injectable, inject } from '@angular/core';

import {
  HistorialMedico
} from '../models/historial.model';

import { EstadoCita } from '../models/cita.model';

import { MascotaService } from './mascota';
import { CitaService } from './cita';
import { AlmacenamientoService } from './almacenamiento';

@Injectable({
  providedIn: 'root'
})
export class HistorialService {

  private readonly STORAGE_KEY = 'vetcontrol_historial';

  private almacenamiento = inject(AlmacenamientoService);
  private mascotaService = inject(MascotaService);
  private citaService = inject(CitaService);

  private historiales: HistorialMedico[] = [];

  constructor() {
    this.cargarDatos();
  }

  // Recuperar historiales almacenados
  private cargarDatos(): void {

    const datos = this.almacenamiento.obtener(this.STORAGE_KEY);

    if (!datos) {
      return;
    }

    try {
      const historialesGuardados: HistorialMedico[] =
        JSON.parse(datos);

      if (!Array.isArray(historialesGuardados)) {
        return;
      }

      this.historiales = historialesGuardados.map(
        historial => ({
          ...historial,
          fechaRegistro: new Date(historial.fechaRegistro)
        })
      );

    } catch (error) {
      console.error(
        'Error al cargar el historial médico:',
        error
      );

      this.historiales = [];
    }
  }

  // Guardar los cambios
  private guardarDatos(): void {

    this.almacenamiento.guardar(
      this.STORAGE_KEY,
      JSON.stringify(this.historiales)
    );
  }

  // Obtener todos los registros médicos
  obtenerTodos(): HistorialMedico[] {
    return [...this.historiales];
  }

  // Buscar un registro médico por ID
  obtenerPorId(id: number): HistorialMedico | undefined {

    return this.historiales.find(
      historial => historial.id === id
    );
  }

  // Obtener historial de una mascota
  obtenerPorMascota(mascotaId: number): HistorialMedico[] {

    return this.historiales
      .filter(
        historial => historial.mascotaId === mascotaId
      )
      .sort(
        (a, b) =>
          b.fechaAtencion.localeCompare(a.fechaAtencion)
      );
  }

  // Buscar atenciones por fecha
  obtenerPorFecha(fecha: string): HistorialMedico[] {

    return this.historiales.filter(
      historial => historial.fechaAtencion === fecha
    );
  }

  // Registrar una atención médica
  registrar(
    datos: Omit<HistorialMedico, 'id' | 'fechaRegistro'>
  ): HistorialMedico {

    this.validarDatos(datos);

    const nuevoHistorial: HistorialMedico = {
      ...datos,
      id: this.generarId(),
      fechaRegistro: new Date()
    };

    this.historiales.push(nuevoHistorial);

    this.guardarDatos();

    return nuevoHistorial;
  }

  // Actualizar un registro médico
  actualizar(
    id: number,
    datos: Partial<HistorialMedico>
  ): boolean {

    const indice = this.historiales.findIndex(
      historial => historial.id === id
    );

    if (indice === -1) {
      return false;
    }

    const historialActual = this.historiales[indice];

    const historialActualizado: HistorialMedico = {
      ...historialActual,
      ...datos,
      id: historialActual.id,
      fechaRegistro: historialActual.fechaRegistro
    };

    this.validarDatos(historialActualizado);

    this.historiales[indice] = historialActualizado;

    this.guardarDatos();

    return true;
  }

  // Eliminar un registro médico
  eliminar(id: number): boolean {

    const indice = this.historiales.findIndex(
      historial => historial.id === id
    );

    if (indice === -1) {
      return false;
    }

    this.historiales.splice(indice, 1);

    this.guardarDatos();

    return true;
  }

  // Validar los datos de una atención médica
  private validarDatos(
    datos: Omit<HistorialMedico, 'id' | 'fechaRegistro'>
  ): void {

    const mascota = this.mascotaService.obtenerPorId(
      datos.mascotaId
    );

    if (!mascota) {
      throw new Error(
        'La mascota seleccionada no existe.'
      );
    }

    if (
      !datos.fechaAtencion ||
      !/^\d{4}-\d{2}-\d{2}$/.test(datos.fechaAtencion)
    ) {
      throw new Error(
        'Debe ingresar una fecha de atención válida.'
      );
    }

    const fechaAtencion = new Date(
      `${datos.fechaAtencion}T00:00:00`
    );

    if (
      Number.isNaN(fechaAtencion.getTime()) ||
      fechaAtencion.getFullYear() !==
        Number(datos.fechaAtencion.slice(0, 4)) ||
      fechaAtencion.getMonth() + 1 !==
        Number(datos.fechaAtencion.slice(5, 7)) ||
      fechaAtencion.getDate() !==
        Number(datos.fechaAtencion.slice(8, 10))
    ) {
      throw new Error(
        'La fecha de atención no existe.'
      );
    }

    const hoy = new Date();
    hoy.setHours(0, 0, 0, 0);

    if (fechaAtencion > hoy) {
      throw new Error(
        'No se pueden registrar atenciones en fechas futuras.'
      );
    }

    if (!datos.tipoAtencion) {
      throw new Error(
        'Debe seleccionar el tipo de atención.'
      );
    }

    if (!datos.motivo?.trim()) {
      throw new Error(
        'Debe ingresar el motivo de la atención.'
      );
    }

    if (!datos.diagnostico?.trim()) {
      throw new Error(
        'Debe ingresar el diagnóstico.'
      );
    }

    if (!datos.tratamiento?.trim()) {
      throw new Error(
        'Debe ingresar el tratamiento.'
      );
    }

    if (!datos.veterinario?.trim()) {
      throw new Error(
        'Debe indicar el veterinario responsable.'
      );
    }

    // Comprobar la cita asociada, si existe
    if (datos.citaId !== undefined) {

      const cita = this.citaService.obtenerPorId(
        datos.citaId
      );

      if (!cita) {
        throw new Error(
          'La cita asociada no existe.'
        );
      }

      if (cita.mascotaId !== datos.mascotaId) {
        throw new Error(
          'La cita no pertenece a la mascota seleccionada.'
        );
      }

      if (cita.estado !== EstadoCita.COMPLETADA) {
        throw new Error(
          'La cita debe estar completada para asociarla al historial.'
        );
      }
    }
  }

  // Generar identificador
  private generarId(): number {

    if (this.historiales.length === 0) {
      return 1;
    }

    return Math.max(
      ...this.historiales.map(historial => historial.id)
    ) + 1;
  }
}
