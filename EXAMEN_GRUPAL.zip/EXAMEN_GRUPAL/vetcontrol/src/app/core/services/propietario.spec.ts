import { TestBed } from '@angular/core/testing';

import { Propietario } from './propietario';

describe('Propietario', () => {
  let service: Propietario;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Propietario);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
