
import { Injectable, inject } from '@angular/core';

import {
  Mascota,
  SexoMascota
} from '../models/mascota.model';

import {
  AlmacenamientoService
} from './almacenamiento';

import {
  PropietarioService
} from './propietario';

@Injectable({
  providedIn: 'root'
})
export class MascotaService {

  private readonly STORAGE_KEY = 'vetcontrol_mascotas';

  private readonly CITAS_KEY = 'vetcontrol_citas';

  private readonly HISTORIAL_KEY = 'vetcontrol_historial';

  private almacenamiento = inject(AlmacenamientoService);

  private propietarioService = inject(PropietarioService);

  private mascotas: Mascota[] = [];

  constructor() {
    this.cargarDatos();
  }

  // ========================================
  // CARGAR MASCOTAS
  // ========================================

  private cargarDatos(): void {

    const datos = this.almacenamiento.obtener(
      this.STORAGE_KEY
    );

    if (!datos) {
      return;
    }

    try {

      const mascotasGuardadas: Mascota[] =
        JSON.parse(datos);

      if (!Array.isArray(mascotasGuardadas)) {
        throw new Error(
          'El almacenamiento de mascotas no contiene una lista válida.'
        );
      }

      this.mascotas = mascotasGuardadas.map(
        mascota => ({
          ...mascota,
          fechaNacimiento: new Date(
            mascota.fechaNacimiento
          ),
          fechaRegistro: new Date(
            mascota.fechaRegistro
          )
        })
      );

    } catch (error) {

      console.error(
        'Error al cargar mascotas:',
        error
      );

      this.mascotas = [];
    }
  }

  // ========================================
  // GUARDAR MASCOTAS
  // ========================================

  private guardarDatos(): void {

    const guardado = this.almacenamiento.guardar(
      this.STORAGE_KEY,
      JSON.stringify(this.mascotas)
    );

    if (!guardado) {
      console.warn(
        'No se pudieron persistir las mascotas.'
      );
    }
  }

  // ========================================
  // OBTENER TODAS LAS MASCOTAS
  // ========================================

  obtenerTodos(): Mascota[] {
    return [...this.mascotas];
  }

  // ========================================
  // OBTENER MASCOTA POR ID
  // ========================================

  obtenerPorId(id: number): Mascota | undefined {

    return this.mascotas.find(
      mascota => mascota.id === id
    );
  }

  // ========================================
  // OBTENER MASCOTAS DE UN PROPIETARIO
  // ========================================

  obtenerPorPropietario(
    propietarioId: number
  ): Mascota[] {

    return this.mascotas.filter(
      mascota =>
        mascota.propietarioId === propietarioId
    );
  }

  // ========================================
  // REGISTRAR MASCOTA
  // ========================================

  registrar(
    datos: Omit<Mascota, 'id' | 'fechaRegistro'>
  ): Mascota {

    const datosNormalizados =
      this.normalizarDatos(datos);

    this.validarDatos(datosNormalizados);

    const nuevaMascota: Mascota = {
      ...datosNormalizados,
      id: this.generarId(),
      fechaRegistro: new Date()
    };

    this.mascotas.push(nuevaMascota);

    this.guardarDatos();

    return nuevaMascota;
  }

  // ========================================
  // ACTUALIZAR MASCOTA
  // ========================================

  actualizar(
    id: number,
    datos: Partial<Mascota>
  ): boolean {

    const indice = this.mascotas.findIndex(
      mascota => mascota.id === id
    );

    if (indice === -1) {
      return false;
    }

    const mascotaActual = this.mascotas[indice];

    const datosActualizados = this.normalizarDatos({
      ...mascotaActual,
      ...datos
    });

    this.validarDatos(datosActualizados);

    this.mascotas[indice] = {
      ...mascotaActual,
      ...datosActualizados,
      id: mascotaActual.id,
      fechaRegistro: mascotaActual.fechaRegistro
    };

    this.guardarDatos();

    return true;
  }

  // ========================================
  // VERIFICAR CITAS ASOCIADAS
  // ========================================

  tieneCitas(mascotaId: number): boolean {

    return this.existenRegistrosRelacionados(
      this.CITAS_KEY,
      mascotaId
    );
  }

  // ========================================
  // VERIFICAR HISTORIAL ASOCIADO
  // ========================================

  tieneHistorial(mascotaId: number): boolean {

    return this.existenRegistrosRelacionados(
      this.HISTORIAL_KEY,
      mascotaId
    );
  }

  // ========================================
  // CONSULTAR REGISTROS RELACIONADOS
  // ========================================

  private existenRegistrosRelacionados(
    clave: string,
    mascotaId: number
  ): boolean {

    const datos = this.almacenamiento.obtener(clave);

    if (!datos) {
      return false;
    }

    try {

      const registros: unknown = JSON.parse(datos);

      if (!Array.isArray(registros)) {
        throw new Error(
          'Los registros relacionados tienen un formato inválido.'
        );
      }

      return registros.some(
        registro =>
          registro !== null &&
          typeof registro === 'object' &&
          registro.mascotaId === mascotaId
      );

    } catch (error) {

      console.error(
        'Error al consultar registros relacionados:',
        error
      );

      throw new Error(
        'No se pudieron verificar los registros asociados a la mascota.'
      );
    }
  }

  // ========================================
  // ELIMINAR MASCOTA
  // ========================================

  eliminar(id: number): boolean {

    const indice = this.mascotas.findIndex(
      mascota => mascota.id === id
    );

    if (indice === -1) {
      return false;
    }

    if (this.tieneCitas(id)) {
      throw new Error(
        'No se puede eliminar esta mascota porque tiene citas registradas.'
      );
    }

    if (this.tieneHistorial(id)) {
      throw new Error(
        'No se puede eliminar esta mascota porque tiene historial médico registrado.'
      );
    }

    this.mascotas.splice(indice, 1);

    this.guardarDatos();

    return true;
  }

  // ========================================
  // NORMALIZAR DATOS
  // ========================================

  private normalizarDatos(
    datos: Omit<Mascota, 'id' | 'fechaRegistro'>
  ): Omit<Mascota, 'id' | 'fechaRegistro'> {

    return {
      nombre: datos.nombre.trim(),
      especie: datos.especie.trim(),
      raza: datos.raza.trim(),
      sexo: datos.sexo,
      fechaNacimiento: new Date(
        datos.fechaNacimiento
      ),
      color: datos.color.trim(),
      peso: Number(datos.peso),
      propietarioId: Number(datos.propietarioId),
      observaciones: (
        datos.observaciones ?? ''
      ).trim()
    };
  }

  // ========================================
  // VALIDAR DATOS
  // ========================================

  private validarDatos(
    datos: Omit<Mascota, 'id' | 'fechaRegistro'>
  ): void {

    if (
      datos.nombre.length < 2 ||
      datos.nombre.length > 60
    ) {
      throw new Error(
        'El nombre de la mascota debe contener entre 2 y 60 caracteres.'
      );
    }

    if (!datos.especie) {
      throw new Error(
        'Debe seleccionar una especie.'
      );
    }

    if (
      !datos.raza ||
      datos.raza.length > 60
    ) {
      throw new Error(
        'Debe ingresar una raza válida.'
      );
    }

    if (
      datos.sexo !== SexoMascota.MACHO &&
      datos.sexo !== SexoMascota.HEMBRA
    ) {
      throw new Error(
        'Debe seleccionar un sexo válido.'
      );
    }

    const fechaNacimiento = new Date(
      datos.fechaNacimiento
    );

    if (Number.isNaN(fechaNacimiento.getTime())) {
      throw new Error(
        'La fecha de nacimiento no es válida.'
      );
    }

    const hoy = new Date();

    hoy.setHours(0, 0, 0, 0);

    const nacimientoNormalizado =
      new Date(fechaNacimiento);

    nacimientoNormalizado.setHours(0, 0, 0, 0);

    if (nacimientoNormalizado > hoy) {
      throw new Error(
        'La fecha de nacimiento no puede ser futura.'
      );
    }

    if (
      !datos.color ||
      datos.color.length > 50
    ) {
      throw new Error(
        'Debe ingresar un color válido.'
      );
    }

    if (
      !Number.isFinite(datos.peso) ||
      datos.peso <= 0 ||
      datos.peso > 500
    ) {
      throw new Error(
        'El peso debe ser mayor que 0 y no superar 500 kg.'
      );
    }

    if (
      !Number.isInteger(datos.propietarioId) ||
      datos.propietarioId <= 0
    ) {
      throw new Error(
        'Debe seleccionar un propietario válido.'
      );
    }

    const propietario =
      this.propietarioService.obtenerPorId(
        datos.propietarioId
      );

    if (!propietario) {
      throw new Error(
        'El propietario seleccionado no existe.'
      );
    }

    if ((datos.observaciones ?? '').length > 500) {
      throw new Error(
        'Las observaciones no pueden superar los 500 caracteres.'
      );
    }
  }

  // ========================================
  // GENERAR IDENTIFICADOR
  // ========================================

  private generarId(): number {

    if (this.mascotas.length === 0) {
      return 1;
    }

    return Math.max(
      ...this.mascotas.map(
        mascota => mascota.id
      )
    ) + 1;
  }
}
