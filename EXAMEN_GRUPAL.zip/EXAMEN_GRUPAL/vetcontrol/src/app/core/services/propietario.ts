
import { Injectable, inject } from '@angular/core';

import {
  Propietario
} from '../models/propietario.model';

import {
  AlmacenamientoService
} from './almacenamiento';

@Injectable({
  providedIn: 'root'
})
export class PropietarioService {

  private readonly STORAGE_KEY = 'vetcontrol_propietarios';
  private readonly MASCOTAS_KEY = 'vetcontrol_mascotas';

  private almacenamiento = inject(AlmacenamientoService);

  private propietarios: Propietario[] = [];

  constructor() {
    this.cargarDatos();
  }

  // ========================================
  // CARGAR PROPIETARIOS
  // ========================================

  private cargarDatos(): void {

    const datos = this.almacenamiento.obtener(
      this.STORAGE_KEY
    );

    if (!datos) {
      return;
    }

    try {

      const propietariosGuardados: Propietario[] =
        JSON.parse(datos);

      if (!Array.isArray(propietariosGuardados)) {
        return;
      }

      this.propietarios = propietariosGuardados.map(
        propietario => ({
          ...propietario,
          fechaRegistro: new Date(
            propietario.fechaRegistro
          )
        })
      );

    } catch (error) {

      console.error(
        'Error al cargar propietarios:',
        error
      );

      this.propietarios = [];
    }
  }

  // ========================================
  // GUARDAR PROPIETARIOS
  // ========================================

  private guardarDatos(): void {

    const guardado = this.almacenamiento.guardar(
      this.STORAGE_KEY,
      JSON.stringify(this.propietarios)
    );

    if (!guardado) {
      console.warn(
        'No se pudieron persistir los propietarios.'
      );
    }
  }

  // ========================================
  // CONSULTAR PROPIETARIOS
  // ========================================

  obtenerTodos(): Propietario[] {
    return [...this.propietarios];
  }

  obtenerPorId(id: number): Propietario | undefined {

    return this.propietarios.find(
      propietario => propietario.id === id
    );
  }

  // ========================================
  // VERIFICAR DNI DUPLICADO
  // ========================================

  existeDni(
    dni: string,
    excluirId?: number
  ): boolean {

    return this.propietarios.some(
      propietario =>
        propietario.dni === dni.trim() &&
        propietario.id !== excluirId
    );
  }

  // ========================================
  // VERIFICAR CORREO DUPLICADO
  // ========================================

  existeCorreo(
    correo: string,
    excluirId?: number
  ): boolean {

    return this.propietarios.some(
      propietario =>
        propietario.correo.toLowerCase() ===
          correo.trim().toLowerCase() &&
        propietario.id !== excluirId
    );
  }

  // ========================================
  // REGISTRAR PROPIETARIO
  // ========================================

  registrar(
    datos: Omit<Propietario, 'id' | 'fechaRegistro'>
  ): Propietario {

    const datosNormalizados =
      this.normalizarDatos(datos);

    this.validarDatos(datosNormalizados);

    if (this.existeDni(datosNormalizados.dni)) {
      throw new Error(
        'Ya existe un propietario registrado con ese DNI.'
      );
    }

    if (this.existeCorreo(datosNormalizados.correo)) {
      throw new Error(
        'Ya existe un propietario registrado con ese correo.'
      );
    }

    const nuevoPropietario: Propietario = {
      ...datosNormalizados,
      id: this.generarId(),
      fechaRegistro: new Date()
    };

    this.propietarios.push(nuevoPropietario);

    this.guardarDatos();

    return nuevoPropietario;
  }

  // ========================================
  // ACTUALIZAR PROPIETARIO
  // ========================================

  actualizar(
    id: number,
    datos: Partial<Propietario>
  ): boolean {

    const indice = this.propietarios.findIndex(
      propietario => propietario.id === id
    );

    if (indice === -1) {
      return false;
    }

    const propietarioActual = this.propietarios[indice];

    const datosActualizados = this.normalizarDatos({
      ...propietarioActual,
      ...datos
    });

    this.validarDatos(datosActualizados);

    if (this.existeDni(datosActualizados.dni, id)) {
      throw new Error(
        'El DNI ya pertenece a otro propietario.'
      );
    }

    if (this.existeCorreo(datosActualizados.correo, id)) {
      throw new Error(
        'El correo ya pertenece a otro propietario.'
      );
    }

    this.propietarios[indice] = {
      ...propietarioActual,
      ...datosActualizados,
      id: propietarioActual.id,
      fechaRegistro: propietarioActual.fechaRegistro
    };

    this.guardarDatos();

    return true;
  }

  // ========================================
  // VERIFICAR MASCOTAS ASOCIADAS
  // ========================================

  tieneMascotas(propietarioId: number): boolean {

    const datos = this.almacenamiento.obtener(
      this.MASCOTAS_KEY
    );

    if (!datos) {
      return false;
    }

    try {

      const mascotas: unknown = JSON.parse(datos);

      if (!Array.isArray(mascotas)) {
        throw new Error(
          'El almacenamiento de mascotas no tiene un formato válido.'
        );
      }

      return mascotas.some(
        mascota =>
          mascota !== null &&
          typeof mascota === 'object' &&
          mascota.propietarioId === propietarioId
      );

    } catch (error) {

      console.error(
        'Error al consultar mascotas asociadas:',
        error
      );

      // Ante datos ilegibles, se bloquea la eliminación.
      throw new Error(
        'No se pudo verificar si el propietario tiene mascotas asociadas.'
      );
    }
  }

  // ========================================
  // ELIMINAR PROPIETARIO
  // ========================================

  eliminar(id: number): boolean {

    const indice = this.propietarios.findIndex(
      propietario => propietario.id === id
    );

    if (indice === -1) {
      return false;
    }

    if (this.tieneMascotas(id)) {
      throw new Error(
        'No se puede eliminar este propietario porque tiene mascotas registradas.'
      );
    }

    this.propietarios.splice(indice, 1);

    this.guardarDatos();

    return true;
  }

  // ========================================
  // NORMALIZAR DATOS
  // ========================================

  private normalizarDatos(
    datos: Omit<Propietario, 'id' | 'fechaRegistro'>
  ): Omit<Propietario, 'id' | 'fechaRegistro'> {

    return {
      nombres: datos.nombres.trim(),
      apellidos: datos.apellidos.trim(),
      dni: datos.dni.trim(),
      telefono: datos.telefono.trim(),
      correo: datos.correo.trim().toLowerCase(),
      direccion: (datos.direccion ?? '').trim()
    };
  }

  // ========================================
  // VALIDAR DATOS
  // ========================================

  private validarDatos(
    datos: Omit<Propietario, 'id' | 'fechaRegistro'>
  ): void {

    if (
      datos.nombres.length < 3 ||
      datos.nombres.length > 60
    ) {
      throw new Error(
        'Los nombres deben contener entre 3 y 60 caracteres.'
      );
    }

    if (
      datos.apellidos.length < 3 ||
      datos.apellidos.length > 60
    ) {
      throw new Error(
        'Los apellidos deben contener entre 3 y 60 caracteres.'
      );
    }

    if (!/^\d{8}$/.test(datos.dni)) {
      throw new Error(
        'El DNI debe contener exactamente 8 dígitos.'
      );
    }

    if (!/^9\d{8}$/.test(datos.telefono)) {
      throw new Error(
        'El teléfono debe contener 9 dígitos y comenzar con 9.'
      );
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(datos.correo)) {
      throw new Error(
        'Ingrese un correo electrónico válido.'
      );
    }

    if ((datos.direccion ?? '').length > 150) {
      throw new Error(
        'La dirección no puede superar los 150 caracteres.'
      );
    }
  }

  // ========================================
  // GENERAR ID
  // ========================================

  private generarId(): number {

    if (this.propietarios.length === 0) {
      return 1;
    }

    return Math.max(
      ...this.propietarios.map(
        propietario => propietario.id
      )
    ) + 1;
  }
}
