
import { Injectable, inject } from '@angular/core';

import {
  Cita,
  EstadoCita
} from '../models/cita.model';

import { MascotaService } from './mascota';

import { AlmacenamientoService } from './almacenamiento';

@Injectable({
  providedIn: 'root'
})
export class CitaService {

  private readonly STORAGE_KEY = 'vetcontrol_citas';

  private readonly HISTORIAL_KEY = 'vetcontrol_historial';

  private almacenamiento = inject(AlmacenamientoService);

  private mascotaService = inject(MascotaService);

  private citas: Cita[] = [];

  readonly HORARIOS: string[] = [
    '08:00',
    '09:00',
    '10:00',
    '11:00',
    '12:00',
    '14:00',
    '15:00',
    '16:00',
    '17:00',
    '18:00'
  ];

  constructor() {
    this.cargarDatos();
  }

  // ========================================
  // CARGAR DATOS
  // ========================================

  private cargarDatos(): void {

    const datos = this.almacenamiento.obtener(
      this.STORAGE_KEY
    );

    if (!datos) {
      return;
    }

    try {

      const registros: unknown = JSON.parse(datos);

      if (!Array.isArray(registros)) {
        throw new Error('Formato de citas inválido.');
      }

      this.citas = registros.map(
        (cita: Cita) => ({
          ...cita,
          fechaRegistro: new Date(cita.fechaRegistro)
        })
      );

    } catch (error) {

      console.error('Error al cargar citas:', error);

      this.citas = [];
    }
  }

  // ========================================
  // GUARDAR DATOS
  // ========================================

  private guardarDatos(): void {

    const guardado = this.almacenamiento.guardar(
      this.STORAGE_KEY,
      JSON.stringify(this.citas)
    );

    if (!guardado) {
      console.warn('No se pudieron persistir las citas.');
    }
  }

  // ========================================
  // CONSULTAS
  // ========================================

  obtenerTodos(): Cita[] {
    return [...this.citas];
  }

  obtenerPorId(id: number): Cita | undefined {

    return this.citas.find(cita => cita.id === id);
  }

  obtenerPorMascota(mascotaId: number): Cita[] {

    return this.citas.filter(
      cita => cita.mascotaId === mascotaId
    );
  }

  obtenerPorFecha(fecha: string): Cita[] {

    return this.citas.filter(
      cita => cita.fecha === fecha
    );
  }

  // ========================================
  // VALIDACIÓN DE HORARIOS
  // ========================================

  horarioDisponible(
    fecha: string,
    hora: string,
    veterinario: string,
    excluirId?: number
  ): boolean {

    const nombre = veterinario.trim().toLowerCase();

    return !this.citas.some(cita =>
      cita.id !== excluirId &&
      cita.fecha === fecha &&
      cita.hora === hora &&
      cita.veterinario.trim().toLowerCase() === nombre &&
      cita.estado !== EstadoCita.CANCELADA
    );
  }

  obtenerHorariosDisponibles(
    fecha: string,
    veterinario: string,
    excluirId?: number
  ): string[] {

    return this.HORARIOS.filter(hora =>
      this.horarioDisponible(
        fecha,
        hora,
        veterinario,
        excluirId
      )
    );
  }

  // ========================================
  // REGISTRAR CITA
  // ========================================

  registrar(
    datos: Omit<Cita, 'id' | 'fechaRegistro'>
  ): Cita {

    const datosNormalizados = this.normalizarDatos(datos);

    if (datosNormalizados.estado !== EstadoCita.PENDIENTE) {
      throw new Error(
        'Las citas nuevas deben registrarse como Pendiente.'
      );
    }

    this.validarDatos(datosNormalizados);

    if (!this.horarioDisponible(
      datosNormalizados.fecha,
      datosNormalizados.hora,
      datosNormalizados.veterinario
    )) {
      throw new Error(
        'El veterinario ya tiene una cita en esa fecha y hora.'
      );
    }

    const nuevaCita: Cita = {
      ...datosNormalizados,
      id: this.generarId(),
      fechaRegistro: new Date()
    };

    this.citas.push(nuevaCita);

    this.guardarDatos();

    return nuevaCita;
  }

  // ========================================
  // ACTUALIZAR CITA
  // ========================================

  actualizar(
    id: number,
    datos: Partial<Cita>
  ): boolean {

    const indice = this.citas.findIndex(
      cita => cita.id === id
    );

    if (indice === -1) {
      return false;
    }

    const actual = this.citas[indice];

    const actualizada = this.normalizarDatos({
      ...actual,
      ...datos
    });

    const tieneHistorial = this.tieneHistorial(id);

    if (tieneHistorial) {

      if (
        actualizada.mascotaId !== actual.mascotaId ||
        actualizada.estado !== EstadoCita.COMPLETADA
      ) {
        throw new Error(
          'No puede cambiar la mascota ni el estado de una cita con historial médico.'
        );
      }

      if (
        actualizada.fecha !== actual.fecha ||
        actualizada.hora !== actual.hora
      ) {
        throw new Error(
          'No puede modificar la fecha ni la hora de una cita con historial médico.'
        );
      }
    }

    if (actualizada.estado !== actual.estado) {
      this.validarTransicion(
        actual.estado,
        actualizada.estado
      );
    }

    const cambioProgramacion =
      actualizada.fecha !== actual.fecha ||
      actualizada.hora !== actual.hora ||
      actualizada.veterinario.toLowerCase() !==
        actual.veterinario.toLowerCase();

    this.validarDatos(
      actualizada,
      !cambioProgramacion,
      id
    );

    if (
      actualizada.estado !== EstadoCita.CANCELADA &&
      !this.horarioDisponible(
        actualizada.fecha,
        actualizada.hora,
        actualizada.veterinario,
        id
      )
    ) {
      throw new Error(
        'El veterinario ya tiene una cita registrada en ese horario.'
      );
    }

    this.citas[indice] = {
      ...actual,
      ...actualizada,
      id: actual.id,
      fechaRegistro: actual.fechaRegistro
    };

    this.guardarDatos();

    return true;
  }

  // ========================================
  // CAMBIAR ESTADO
  // ========================================

  cambiarEstado(
    id: number,
    nuevoEstado: EstadoCita
  ): boolean {

    const cita = this.obtenerPorId(id);

    if (!cita) {
      return false;
    }

    if (cita.estado === nuevoEstado) {
      return true;
    }

    this.validarTransicion(cita.estado, nuevoEstado);

    if (
      this.tieneHistorial(id) &&
      nuevoEstado !== EstadoCita.COMPLETADA
    ) {
      throw new Error(
        'No se puede cambiar el estado de una cita vinculada a un historial médico.'
      );
    }

    if (
      nuevoEstado !== EstadoCita.CANCELADA &&
      !this.horarioDisponible(
        cita.fecha,
        cita.hora,
        cita.veterinario,
        id
      )
    ) {
      throw new Error(
        'Existe un conflicto de horario para este veterinario.'
      );
    }

    cita.estado = nuevoEstado;

    this.guardarDatos();

    return true;
  }

  // ========================================
  // VALIDAR CAMBIOS DE ESTADO
  // ========================================

  private validarTransicion(
    actual: EstadoCita,
    nuevo: EstadoCita
  ): void {

    const permitidos: Record<EstadoCita, EstadoCita[]> = {

      [EstadoCita.PENDIENTE]: [
        EstadoCita.CONFIRMADA,
        EstadoCita.CANCELADA
      ],

      [EstadoCita.CONFIRMADA]: [
        EstadoCita.EN_ATENCION,
        EstadoCita.CANCELADA
      ],

      [EstadoCita.EN_ATENCION]: [
        EstadoCita.COMPLETADA
      ],

      [EstadoCita.COMPLETADA]: [],

      [EstadoCita.CANCELADA]: []
    };

    if (!permitidos[actual]?.includes(nuevo)) {
      throw new Error(
        `No se permite cambiar una cita de "${actual}" a "${nuevo}".`
      );
    }
  }

  // ========================================
  // CANCELAR CITA
  // ========================================

  cancelar(id: number): boolean {

    return this.cambiarEstado(
      id,
      EstadoCita.CANCELADA
    );
  }

  // ========================================
  // VERIFICAR HISTORIAL ASOCIADO
  // ========================================

  tieneHistorial(citaId: number): boolean {

    const datos = this.almacenamiento.obtener(
      this.HISTORIAL_KEY
    );

    if (!datos) {
      return false;
    }

    try {

      const registros: unknown = JSON.parse(datos);

      if (!Array.isArray(registros)) {
        throw new Error('Formato de historial inválido.');
      }

      return registros.some(registro =>
        registro !== null &&
        typeof registro === 'object' &&
        registro.citaId === citaId
      );

    } catch (error) {

      console.error(
        'Error al verificar historial:',
        error
      );

      throw new Error(
        'No se pudo verificar el historial médico asociado.'
      );
    }
  }

  // ========================================
  // ELIMINAR CITA
  // ========================================

  eliminar(id: number): boolean {

    const indice = this.citas.findIndex(
      cita => cita.id === id
    );

    if (indice === -1) {
      return false;
    }

    if (this.tieneHistorial(id)) {
      throw new Error(
        'No se puede eliminar esta cita porque tiene un historial médico asociado.'
      );
    }

    this.citas.splice(indice, 1);

    this.guardarDatos();

    return true;
  }

  // ========================================
  // NORMALIZACIÓN DE DATOS
  // ========================================

  private normalizarDatos(
    datos: Omit<Cita, 'id' | 'fechaRegistro'>
  ): Omit<Cita, 'id' | 'fechaRegistro'> {

    return {
      mascotaId: Number(datos.mascotaId),
      fecha: String(datos.fecha).trim(),
      hora: String(datos.hora).trim(),
      motivo: String(datos.motivo).trim(),
      veterinario: String(datos.veterinario).trim(),
      estado: datos.estado,
      observaciones: String(
        datos.observaciones ?? ''
      ).trim()
    };
  }

  // ========================================
  // VALIDACIÓN GENERAL
  // ========================================

  private validarDatos(
    datos: Omit<Cita, 'id' | 'fechaRegistro'>,
    permitirFechaPasada = false,
    excluirId?: number
  ): void {

    if (!Number.isInteger(datos.mascotaId)) {
      throw new Error('Seleccione una mascota válida.');
    }

    if (!this.mascotaService.obtenerPorId(datos.mascotaId)) {
      throw new Error('La mascota seleccionada no existe.');
    }

    if (!/^\d{4}-\d{2}-\d{2}$/.test(datos.fecha)) {
      throw new Error('Formato de fecha incorrecto.');
    }

    const fecha = new Date(
      `${datos.fecha}T00:00:00`
    );

    if (
      Number.isNaN(fecha.getTime()) ||
      this.obtenerFechaLocal(fecha) !== datos.fecha
    ) {
      throw new Error('La fecha de la cita no es válida.');
    }

    const hoy = this.obtenerFechaLocal(new Date());

    if (!permitirFechaPasada && datos.fecha < hoy) {
      throw new Error(
        'No se pueden programar citas en fechas pasadas.'
      );
    }

    if (!this.HORARIOS.includes(datos.hora)) {
      throw new Error('El horario seleccionado no es válido.');
    }

    if (
      datos.motivo.length < 1 ||
      datos.motivo.length > 200
    ) {
      throw new Error(
        'El motivo debe contener entre 1 y 200 caracteres.'
      );
    }

    if (
      datos.veterinario.length < 3 ||
      datos.veterinario.length > 100
    ) {
      throw new Error(
        'El nombre del veterinario debe contener entre 3 y 100 caracteres.'
      );
    }

    if (!Object.values(EstadoCita).includes(datos.estado)) {
      throw new Error('El estado de la cita no es válido.');
    }

    if ((datos.observaciones ?? '').length > 500) {
      throw new Error(
        'Las observaciones no pueden superar 500 caracteres.'
      );
    }

    if (
      datos.estado !== EstadoCita.CANCELADA &&
      !this.horarioDisponible(
        datos.fecha,
        datos.hora,
        datos.veterinario,
        excluirId
      )
    ) {
      throw new Error(
        'El veterinario ya tiene una cita en ese horario.'
      );
    }
  }

  // ========================================
  // FECHA LOCAL
  // ========================================

  private obtenerFechaLocal(fecha: Date): string {

    const anio = fecha.getFullYear();

    const mes = String(
      fecha.getMonth() + 1
    ).padStart(2, '0');

    const dia = String(
      fecha.getDate()
    ).padStart(2, '0');

    return `${anio}-${mes}-${dia}`;
  }

  // ========================================
  // GENERAR ID
  // ========================================

  private generarId(): number {

    if (this.citas.length === 0) {
      return 1;
    }

    return Math.max(
      ...this.citas.map(cita => cita.id)
    ) + 1;
  }
}
