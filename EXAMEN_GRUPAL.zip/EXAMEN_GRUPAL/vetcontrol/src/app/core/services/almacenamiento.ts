
import { Injectable, inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class AlmacenamientoService {

  private platformId = inject(PLATFORM_ID);

  private esNavegador: boolean =
    isPlatformBrowser(this.platformId);

  obtener(clave: string): string | null {

    if (!this.esNavegador) {
      return null;
    }

    try {
      return localStorage.getItem(clave);
    } catch {
      return null;
    }
  }

  guardar(clave: string, valor: string): boolean {

    if (!this.esNavegador) {
      return false;
    }

    try {
      localStorage.setItem(clave, valor);
      return true;
    } catch {
      return false;
    }
  }

  eliminar(clave: string): boolean {

    if (!this.esNavegador) {
      return false;
    }

    try {
      localStorage.removeItem(clave);
      return true;
    } catch {
      return false;
    }
  }

  limpiar(): boolean {

    if (!this.esNavegador) {
      return false;
    }

    try {
      localStorage.clear();
      return true;
    } catch {
      return false;
    }
  }
}
