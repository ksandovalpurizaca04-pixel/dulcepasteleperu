
export enum TipoAtencion {
  CONSULTA = 'Consulta general',
  VACUNACION = 'Vacunación',
  DESPARASITACION = 'Desparasitación',
  CIRUGIA = 'Cirugía',
  EMERGENCIA = 'Emergencia',
  CONTROL = 'Control médico',
  OTRO = 'Otro'
}

export interface HistorialMedico {
  id: number;
  mascotaId: number;
  citaId?: number;
  fechaAtencion: string;
  tipoAtencion: TipoAtencion;
  motivo: string;
  diagnostico: string;
  tratamiento: string;
  medicamentos?: string;
  observaciones?: string;
  veterinario: string;
  proximaVisita?: string;
  fechaRegistro: Date;
}
