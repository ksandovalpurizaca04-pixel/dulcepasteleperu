
export interface Propietario {
  id: number;
  nombres: string;
  apellidos: string;
  dni: string;
  telefono: string;
  correo: string;
  direccion?: string;
  fechaRegistro: Date;
}
