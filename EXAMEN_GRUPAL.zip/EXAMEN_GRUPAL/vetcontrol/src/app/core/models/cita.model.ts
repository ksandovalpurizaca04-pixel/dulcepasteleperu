
export enum EstadoCita {
  PENDIENTE = 'Pendiente',
  CONFIRMADA = 'Confirmada',
  EN_ATENCION = 'En atención',
  COMPLETADA = 'Completada',
  CANCELADA = 'Cancelada'
}

export interface Cita {
  id: number;
  mascotaId: number;
  fecha: string;
  hora: string;
  motivo: string;
  veterinario: string;
  estado: EstadoCita;
  observaciones?: string;
  fechaRegistro: Date;
}
