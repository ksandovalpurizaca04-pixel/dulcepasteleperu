
export enum SexoMascota {
  MACHO = 'Macho',
  HEMBRA = 'Hembra'
}

export interface Mascota {
  id: number;
  nombre: string;
  especie: string;
  raza: string;
  sexo: SexoMascota;
  fechaNacimiento: Date;
  color: string;
  peso: number;
  propietarioId: number;
  observaciones?: string;
  fechaRegistro: Date;
}
